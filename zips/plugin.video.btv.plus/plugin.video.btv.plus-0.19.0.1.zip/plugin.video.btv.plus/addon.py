# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.error, urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.btv.plus'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.btv.plus')


#Деклариране на константи
md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
MUA = 'Mozilla/5.0 (Linux; Android 7.1.1; en-us; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19' #За симулиране на заявка от мобилно устройство
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0' #За симулиране на заявка от  компютърен браузър
bu = 'https://btvplus.bg'

#Хедъри за заявки услугата
bp_headers = {
	'User-Agent': UA,
	'authority': 'btvplus.bg',
	'accept': 'text/html, application/xhtml+xml, application/xml, application/json, text/plain, */*',
	'dnt': '1',
	'origin': bu,
	'Connection': 'keep-alive',
	'sec-fetch-site': 'cross-site',
	'sec-fetch-mode': 'cors',
	'sec-fetch-dest': 'empty',
	'referer': bu,
	'accept-language': 'bg-BG,bg;q=0.9,en;q=0.8',
	'Accept-Encoding': 'gzip'
					}


#Меню с директории в приставката
def CATEGORIES():
		#addDir('Search',bu+'/search/?q=','',5,md+'DefaultAddonsSearch.png') #Съдържанието е минимално и няма нужда от търсачка
		addLink('btv на Живо','https://btvplus.bg/lbin/v3/btvplus/player_config.php?media_id=2110383625','','True','','','','',4,'http://logos.kodibg.org/btv.png')
		addDir('Предавания',bu+'/predavaniya/','Предаванията на bTV',1,md+'DefaultFolder.png')
		addDir('Сериали',bu+'/seriali/','Сериалите, излъчвани по bTV',1,md+'DefaultFolder.png')
		addDir('Емисии',bu+'/novini/','Записи на емисии новини, спорт и прогноза за времето',1,md+'DefaultFolder.png')
		
		

#Разлистване на всички заглавия в каталога
def LISTALL(url):
		#xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
		response = requests.get(url, headers=bp_headers)
		match = re.compile('<li.+>\n	+<div class=\"image\">\n	+<a href=\"(.+?)\">\n	+<img src=\"(.+?)\" />\n	+</a>\n	+</div>	\n	+</li>').findall(response.text)
		for link, cover in match:
			title = link.rsplit('/', 1)[1].replace('-',' ').capitalize()
			if 'http' not in cover:
				cover = 'http:'+cover
			addDir(title,link,'',2,cover)
		if 'novini' in url:
			addDir('Новини','/search/?type=101','',2,md+'DefaultFolder.png')
			addDir('Спорт','/search/?type=102','',2,md+'DefaultFolder.png')
			addDir('Времето','/search/?type=103','',2,md+'DefaultFolder.png')


#Разлистване епизодите
def LISTEPISODES(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
		response = requests.get(bu+url, headers=bp_headers)
		cover = ''
		match1 = re.compile('<h4>\n.{1,10}<a href=\"(.+?)\".{0,20}>(.+?)</a>\n.{1,10}</h4>').findall(response.text)
		for link, name in set(match1): #Премахни дубликатите
			title = name
			try:
				matchp = re.compile('<meta itemprop=\"description\" content=\"(.+?)\" />').findall(response.text.replace("\n", ""))
				for description in matchp:
					plot = description
			except:
				plot = ''
			try:
				matchc = re.compile('<meta property=\"og:image\" content=\"(.+?)\" />').findall(response.text)
				for coverimage in matchc:
					if 'http' not in coverimage:
						coverimage = 'http:' + coverimage
					cover = coverimage
			except:
				cover = ''
			if ((url.rsplit('/', 1)[1] in link) or ('type=' in url)): #Ако е правилното предаване или е новинарска емисия
				addLink(title,link,'','True',plot,'','','',3,cover)
		xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE) #Подреди списъка


#Зареждане на видео
def PLAY(url):
		if 'm3u8' in url:
			li = xbmcgui.ListItem(path=url+'|User-Agent='+UA+'&connection-timeout=930&verifypeer=false')
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
		else:
			response = requests.get(bu+url, headers=bp_headers)
			matcht = re.compile('<meta property=\"og:title\" content=\"(.+?)\" />').findall(response.text)
			for name in matcht:
				title = name
				plot = title
				matchl = re.compile('\"contentUrl\": \"(.+?)\",').findall(response.text)
				for adres in matchl:
					link = adres
				try:
					matchc = re.compile('\"thumbnailUrl\": \"(.+?)\",').findall(response.text)
					for coverimage in matchc:
						cover = coverimage
				except:
					cover = md+'DefaultMovies.png'
				
				try:
					stream = link.replace('https:','http:')+'|User-Agent='+UA+'&connection-timeout=930&verifypeer=false'
					li = xbmcgui.ListItem(path=stream)
					li.setArt({ 'thumb': cover,'poster': cover, 'banner' : cover, 'fanart': cover, 'icon': cover })
					li.setInfo( type="Video", infoLabels={ 'Title': title, 'Plot': plot } )
					xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
				except:
					xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('BTV PLUS','Видеото е премахнато!\nИма го във Voyo.bg', 4000, md+'DefaultIconError.png'))


#Гледане на живо
def LIVE(url):
		response = requests.get(url, headers=bp_headers)
		matchl = re.compile('file\":\"(.+?)\",').findall(response.text)
		for adres in matchl:
			link = adres.replace('\/','/')
			PLAY(link)


#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,vd,hd,plot,author,rating,ar,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
		liz.setInfo( type="Video", infoLabels={ "title": name, "duration": vd, "plot": plot, "rating": ar, "studio": author, "mpaa": rating } )
		if hd=='True':
			liz.addStreamInfo('video', { 'width': 1280, 'height': 720 })
			liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		else:
			liz.addStreamInfo('video', { 'width': 720, 'height': 480 })
			liz.addStreamInfo('video', { 'aspect': 1.5, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,plot,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		LISTALL(url)

elif mode==2:
		LISTEPISODES(url)

elif mode==3:
		PLAY(url)

elif mode==4:
		LIVE(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
