# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import json
import urllib.request, urllib.error, urllib.parse
import requests
import html
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import YDStreamUtils
import YDStreamExtractor
import inputstreamhelper


#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.cinehouse'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.cinehouse')

#Прочита настройките на приставката
dsorted = __settings__.getSetting("alpha")

#Деклариране на константи
md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "resources/media/")
MUA = 'Mozilla/5.0 (Linux; Android 7.1.1; en-us; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19' #За симулиране на заявка от мобилно устройство
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:92.0) Gecko/20100101 Firefox/92.0' #За симулиране на заявка от  компютърен браузър
bu = 'https://www.cinehousetv.com'
API = 'https://api.yuyutv.com'
start = 0

#Хедъри за заявки към услугата
ch_headers = {
	'User-Agent': UA,
	'accept': 'application/json, text/plain, */*',
	'origin': 'https://www.cinehousetv.com',
	'Connection': 'keep-alive',
	'referer': 'https://www.cinehousetv.com/',
	'accept-language': 'en-US;q=0.7,en;q=0.3',
	'Accept-Encoding': 'gzip'
					}

#Меню с директории в приставката
def CATEGORIES():
		response = requests.get(bu, headers=ch_headers)
		matchp = re.compile(',"buildId":"(.+?)",').findall(response.text)
		for secret in matchp:
			#https://www.cinehousetv.com/_next/data/ThRJ3h8F7Jl5tDiRv44II/index.json
			#https://www.cinehousetv.com/_next/data/ThRJ3h8F7Jl5tDiRv44II/browse.json
			response = requests.get(bu+"/_next/data/"+secret+"/index.json", headers=ch_headers)
			jsonrsp = response.json()
			#print (jsonrsp['pageProps']['rows'][0]['name'])
		
		addDir('Search',bu+'/api/v1/dmi/search/','',5,md+'DefaultAddonsSearch.png')

		#Начало на обхождането
		for cats in range(0, len(jsonrsp['pageProps']['rows'])):
			try:
				addDir(jsonrsp['pageProps']['rows'][cats]['name'],jsonrsp['pageProps']['rows'][cats]['params']['parent_id'],'',1,md+'DefaultFolder.png')
			except:
				pass
		


#Разлистване на избраната категория
def LISTC(url):
		data = {'version':12.5,
		'device_type':'desktop',
		'platform':'web',
		'partner':'DMR',
		'connection':'wifi',
		'language':'en',
		'image_format':'poster',
		'cleanup_thumbnails':0,
		'b_image_width':1200,
		'allowAnonymousResume':1,
		'banners':'0',
		'for_user':'0',
		'is_af_request':'0',
		'parent_id':url,
		'parent_type':'collection',
		'type':'collection',
		'use_device_width_widescreen':'1',
		'max':9999,
		'start':0,
		'image_width':300}

		#https://api.yuyutv.com/getreferencedobjects
		response = requests.post(url=API+"/getreferencedobjects", data=data, headers=ch_headers)
		jsonrsp = response.json()
		#print jsonrsp['objects'][0]['name']
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
		for titl in range(0, len(jsonrsp['objects'])):
			try:
				if (jsonrsp['objects'][titl]['type'] == 'collection' or jsonrsp['objects'][titl]['type'] == 'show' or jsonrsp['objects'][titl]['type'] == 'news'): #Ако заглавието е сериал или новини
					addDir(jsonrsp['objects'][titl]['name'],jsonrsp['objects'][titl]['id'],jsonrsp['objects'][titl]['long_description'],2,jsonrsp['objects'][titl]['thumbnail_url'])
				elif (jsonrsp['objects'][titl]['type'] == 'video' or jsonrsp['objects'][titl]['type'] == 'movie'): #Ако заглавието е филм
					addLink(jsonrsp['objects'][titl]['name'],jsonrsp['objects'][titl]['id'],jsonrsp['objects'][titl]['long_description'],jsonrsp['objects'][titl]['duration'],3,jsonrsp['objects'][titl]['thumbnail_url'])
			except:
				pass




#Разлистване на всички епизоди
def LISTE(url,start):
		#print (url)
		data = {'version':12.5,
		'device_type':'desktop',
		'platform':'web',
		'partner':'DMR',
		'connection':'wifi',
		'language':'en',
		'image_format':'poster',
		'cleanup_thumbnails':0,
		'b_image_width':1200,
		'allowAnonymousResume':1,
		'banners':'0',
		'for_user':'0',
		'is_af_request':'0',
		'parent_id':url,
		'parent_type':'collection',
		'type':'collection',
		'use_device_width_widescreen':'1',
		'max':9999,
		'start':start,
		'image_width':300}

		#https://www.cinehousetv.com/api/v1/dmi/getEpisodes/21373
		response = requests.post(bu+'/api/v1/dmi/getEpisodes/'+url, data=data, headers=ch_headers)
		jsonrsp = response.json()
		#print jsonrsp['objects'][0]['name']
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'episode')
		total = jsonrsp['total_results']
		dosega = start
		for epi in range(0, len(jsonrsp['objects'])):
			try:
				#YouTube-DL
				#addLink(jsonrsp['objects'][epi]['show_info']['show_name']+" S"+jsonrsp['objects'][epi]['show_info']['season_num']+"E"+jsonrsp['objects'][epi]['show_info']['episode_num']+" "+jsonrsp['objects'][epi]['name'],bu+jsonrsp['objects'][epi]['url'],jsonrsp['objects'][epi]['long_description'],jsonrsp['objects'][epi]['duration'],4,jsonrsp['objects'][epi]['widescreen_thumbnail_url'])
				#Self Extract
				addLink(jsonrsp['objects'][epi]['show_info']['show_name']+" S"+jsonrsp['objects'][epi]['show_info']['season_num']+"E"+jsonrsp['objects'][epi]['show_info']['episode_num']+" "+jsonrsp['objects'][epi]['name'],jsonrsp['objects'][epi]['mpd'],jsonrsp['objects'][epi]['long_description'],jsonrsp['objects'][epi]['duration'],4,jsonrsp['objects'][epi]['widescreen_thumbnail_url'])
				dosega = dosega + 1
			except:
				pass
		if (dosega < int(total)):
			start = dosega
			LISTE(url)



#Разлистване на филма
def LISTM(url):
		#print (url)
		#https://www.cinehousetv.com/api/v1/dmi/getVideo/13614
		response = requests.get(bu+'/api/v1/dmi/getVideo/'+url, headers=ch_headers)
		jsonrsp = response.json()
		#print jsonrsp['objects'][0]['name']
		
		#Отваряне на филма
		PLAY(jsonrsp['objects'][0]['mpd'])




#Зареждане на видео
def PLAY(url):
		#YouTube-DL
		#print (url)
		#vid = YDStreamExtractor.getVideoInfo(url,quality=2) #quality is 0=SD, 1=720p, 2=1080p and is a maximum
		#stream_url = vid.streamURL() #This is what Kodi (XBMC) will play
		#print (stream_url)
		#cover=""
		#title=""
		#plot=""
		#li = xbmcgui.ListItem(path=stream_url)
		#li.setArt({ 'thumb': cover,'poster': cover, 'banner' : cover, 'fanart': cover, 'icon': cover })
		#li.setInfo( type="Video", infoLabels={ 'Title': title, 'Plot': plot } )

		#Inputstream Adaptive
		#thumbnail=""
		url = url.replace('/PR_BR_PH/maxBitrate/MAX_BR_PH/','/1500/maxBitrate/2500/')
		is_helper = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
		if is_helper.check_inputstream():
			li = xbmcgui.ListItem(path=url)
			#li.setArt({ 'thumb': thumbnail,'poster': thumbnail, 'banner' : thumbnail, 'fanart': thumbnail, 'icon': thumbnail })
			#li.setInfo( type="Video", infoLabels={ 'Title': name, 'Plot': plot } )

			li.setMimeType('application/xml+dash')
			li.setContentLookup(False)

			li.setProperty('inputstream', 'inputstream.adaptive')
			li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
			li.setProperty('inputstream.adaptive.stream_headers', 'verifypeer=false&User-Agent='+urllib.parse.quote_plus(UA)+'&Referer=https://www.asiancrush.com')
		try:
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
		except:
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('Cinehouse','Cannot Open The Video', 4000, md+'DefaultIconError.png'))




#Търсачка
def SEARCH(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'season')
		keyb = xbmc.Keyboard('', 'Search in Cinehouse')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.parse.quote_plus(keyb.getText())
			searchText=searchText.replace(' ','+')
			searchurl = url.encode('utf-8') + searchText.encode('utf-8', 'ignore')
			searchurl = searchurl.decode('utf-8')
			#print ('SEARCHING:' + searchurl)
			SR(searchurl)
		else:
			addDir('Go to main menu...','','','',md+'DefaultFolderBack.png')




#Резултати от търсенето
def SR(url):
		#print (url)
		#https://www.asiancrush.com/api/v1/dmi/search/countdown
		response = requests.get(url, headers=ch_headers)
		jsonrsp = response.json()
		#print jsonrsp['objects'][0]['name']
		
		#Категоризиране и пренасочване
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		for titl in range(0, len(jsonrsp['objects'])):
			try:
				if (jsonrsp['objects'][titl]['type'] == 'collection' or jsonrsp['objects'][titl]['type'] == 'show' or jsonrsp['objects'][titl]['type'] == 'news'): #Ако заглавието е сериал или новини
					addDir(jsonrsp['objects'][titl]['name'],jsonrsp['objects'][titl]['id'],jsonrsp['objects'][titl]['long_description'],2,jsonrsp['objects'][titl]['thumbnail_url'])
				elif (jsonrsp['objects'][titl]['type'] == 'video' or jsonrsp['objects'][titl]['type'] == 'movie'): #Ако заглавието е филм
					addLink(jsonrsp['objects'][titl]['name'],jsonrsp['objects'][titl]['id'],jsonrsp['objects'][titl]['long_description'],jsonrsp['objects'][titl]['duration'],3,jsonrsp['objects'][titl]['thumbnail_url'])
			except:
				pass






#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,plot,duration,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
		liz.setInfo( type="Video", infoLabels={ "title": name, "duration": duration, "plot": plot } )
		liz.addStreamInfo('video', { 'width': 1280, 'height': 720 })
		liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok



#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,plot,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		if dsorted=='true':
			xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
		return ok




#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]

		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass



#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()

elif mode==1:
		LISTC(url)

elif mode==2:
		LISTE(url,start)

elif mode==3:
		LISTM(url)

elif mode==4:
		PLAY(url)

elif mode==5:
		SEARCH(url)

elif mode==6:
		SR(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))