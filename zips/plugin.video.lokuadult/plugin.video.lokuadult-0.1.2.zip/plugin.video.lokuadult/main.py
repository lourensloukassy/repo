import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin
import xbmc
import resolveurl as urlresolver

# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

#                      {'name': '',
#                      'thumb': '',
#                      'video': '',
#                      'genre': 'SPORTS'}
#

VIDEOS = {
    'JAPAN VOD XXX': [{
        'name': 'EBOD-399 初拍，J罩杯111cm的巨乳少女 七草千岁',
        'thumb': 'http://img.gjtjjp.com/2017-11/DUT4GCW399.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171030/DUT4GCW399/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'JUFD-378 爆乳美女遭遇色狼 不断堕落的美女秘书',
        'thumb': 'http://img.gjtjjp.com/2017-11/DVM8JYR378.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171030/DVM8JYR378/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'SDDE-365 客房！美食！露天！！一面吸吮天上掉下来的肉棒一面在人气温泉旅馆内泡汤...甚至还一面作爱！！',
        'thumb': 'http://img.gjtjjp.com/2017-11/EJH6CXI365.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171030/EJH6CXI365/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'SHE-095 素人比基尼辣妹对大肉棒兴奋不已!! 海岸潮吹搭讪 九十九里篇',
        'thumb': 'http://img.gjtjjp.com/2017-11/EDT5UKM095.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171030/EDT5UKM095/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'GVG-461 最喜欢巨乳的正太的变态恶作剧 三岛奈津子',
        'thumb': 'http://img.gjtjjp.com/2017-11/GJL9EBT461.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/GJL9EBT461/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name':
        'DVDMS-160 一般男女实验AV 单向玻璃对面是最爱的女友！能看着她被其他男人干到最后就有100万日元！巨乳女友不知道男友在看沉迷于30cm巨根！',
        'thumb': 'http://img.gjtjjp.com/2017-11/SJEB4TKM160.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/SJEB4TKM160/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'GETS-054 让一直自以为是的不良少年喝下女体化春药，让他变成一个淫蕩女人',
        'thumb': 'http://img.gjtjjp.com/2017-11/SJR3YLO054.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/SJR3YLO054/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'KUSR-034 公司里人见人爱 美女秘书巨乳紧缚',
        'thumb': 'http://img.gjtjjp.com/2017-11/RTO7VKD034.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/RTO7VKD034/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'AP-469 公厕美女清洁员体内放尿中出痴汉',
        'thumb': 'http://img.gjtjjp.com/2017-11/PKE5TH469.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/PKE5TH469/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'PRED-006 后仰潮喷射 绝顶中出按摩店 樱井彩',
        'thumb': 'http://img.gjtjjp.com/2017-11/DJE8GHO006.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/DJE8GHO006/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'SHE-468 按摩女的玉手让下体不由自主的勃起硬起来，直接不带套内射！ 21',
        'thumb': 'http://img.gjtjjp.com/2017-11/EJT4HYO468.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/EJT4HYO468/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'PPPD-590 巨乳女老师的诱惑 香椎梨亚',
        'thumb': 'http://img.gjtjjp.com/2017-11/DSN0JKQ590.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/DSN0JKQ590/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'CMD-008 诱惑◆按摩沙龙 麻里梨夏',
        'thumb': 'http://img.gjtjjp.com/2017-11/DA8JKE008.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/DA8JKE008/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'PRED-017 就算快乐到失禁也绝不结束的穷兇极恶胖子的强力交尾 佐佐木明希',
        'thumb': 'http://img.gjtjjp.com/2017-11/DJ9RHY017.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/DJ9RHY017/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'HUNTA-348 穿着小号泳衣的巨乳年轻人妻去旅行露出乳房，下乳让人挪不开目光超兴奋！',
        'thumb': 'http://img.gjtjjp.com/2017-11/AJ2RHY348.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/AJ2RHY348/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'EBOD-591 舞蹈曆10年培养出来的惊人身材和扭腰！！九州超有名偶像组合前成员竟然AV出道！！ 松冈美绪',
        'thumb': 'http://img.gjtjjp.com/2017-11/DFGJ9LOR591.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/DFGJ9LOR591/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name':
        'VOSS-046 家里一直都很贫穷 从小学到高中的外号一直都是穷鬼的我靠着奖学金上了大学，为了赚钱在麵包店打工 对一个巨乳太太一见锺情！',
        'thumb': 'http://img.gjtjjp.com/2017-11/SJKL3TRY046.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/SJKL3TRY046/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'YST-120 我被胁迫了 古川祥子',
        'thumb': 'http://img.gjtjjp.com/2017-11/TJKE6BGT120.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/TJKE6BGT120/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'MMYM-008 完美的丰臀美女 莲实克蕾雅 小姐主演',
        'thumb': 'http://img.gjtjjp.com/2017-11/MBE0FK008.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/MBE0FK008/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'SDMU-675 女人高潮快感是男人的10倍！完全主观 女人视角看自己的身体不停高潮！全是女人的顺从女同女生宿舍',
        'thumb': 'http://img.gjtjjp.com/2017-11/UJEG6TKO675.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/UJEG6TKO675/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'MMOK-002 淫蕩身体巨乳女开始搬家打工',
        'thumb': 'http://img.gjtjjp.com/2017-11/KHW5TJL002.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/KHW5TJL002/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'JKSR-302 「比起玩手机更喜欢玩小穴...（羞）」天然F罩杯巨乳妻搭讪性交 真绪',
        'thumb': 'http://img.gjtjjp.com/2017-11/RHK3OET302.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/RHK3OET302/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }, {
        'name': 'MIAE-107 双重快感！执拗舔乳头＆快速手淫 波木遥',
        'thumb': 'http://img.gjtjjp.com/2017-11/EQM3JKDF107.jpg',
        'video':
        'http://video.feimanzb.com:8091/20171103/EQM3JKDF107/550kb/hls/index.m3u8',
        'genre': 'JAPAN VOD XXX'
    }],
    'LIVE TV XXX FHD': [{
        'name': '<!--DISARANKAN MENGGUNAKAN CLOUDFARE 1.1.1.1 VPN-->',
        'thumb': '',
        'video': '#',
        'genre': ''
    }, {
        'name': '21 Sextury TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6164/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Adult Time TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6166/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Analized HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6168/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Babes HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6172/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Bang Bros HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6173/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Bang! TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6174/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Blacked HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6178/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Moms Teach Sex (18+) TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/46984',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Brazzers eXXtra TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6181/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Brazzers HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6182/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Hustler HD TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15879',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Cherry Pimps TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6185/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Club 17 TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6186/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Beate Uhse TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15888',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Deep Lush TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/40157',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Cum Louder TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6189/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Daughter Swap TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6191/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'DDF Busty TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6193/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'DDF Network TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6194/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Digital Desire HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6195/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Digital Playground HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6196/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Dorcel Club TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6197/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Dusk TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6198/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Extasy HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6201/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Fake Taxi HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6202/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Fap Teens TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6211/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Bad Teens Punished TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/49351',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Step Siblings Caught TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/49355',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Hitzefrei HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6220/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Holed TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6221/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Hot and Mean TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6222/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Hot Guys Fuck TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6223/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Family Pies TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/49359',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Japan HDV TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6225/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Princess Cum TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/49357',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Lethal Hardcore TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6229/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Little Asians HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6230/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Live Cams Adult TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6231/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Lust Cinema TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6232/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'MetArt HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6233/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Teacher Fucks Teens TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/49361',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Monsters Cock TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6235/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Naughty America TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6237/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Nubiles TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6238/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'ox-ax HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6239/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Pink Erotic 3 TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6240/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Playboy Plus TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6242/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Pornstar TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6243/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'POV TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6244/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Private HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6245/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Public Agent TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6246/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Reality Kings HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6247/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'RK Prime TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6248/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Tiny4K TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6258/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Tushy HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6261/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'TushyRAW TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6262/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Vixen HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6265/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'Wicked TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6268/index.m3u8',
        'genre': 'LIVE TV XXX'
    }, {
        'name': 'XY Max HD TV',
        'thumb': '',
        'video': 'http://185.183.34.118/iptv/V4KSK3Y4Z8DVPM/6286/index.m3u8',
        'genre': 'LIVE TV XXX'
    }],
    'ADULT TV ALTERNATIVE': [{
        'name': 'ANAL TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/anal.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'ASIAN TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/asian.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'BIG ASS TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/bigass.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'BIG DICK TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/bigdick.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'BRUNETTE TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://play.iptvxxx.net/brunette.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'BLONDE TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://play.iptvxxx.net/blonde.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'LEO TV',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/7/7f/Leo_TV.png',
        'video': 'http://213.151.233.20:8000/dna-6233-tv-pc/hls/4004v105.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'HUSTLER TV HD',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/HustlerTV.svg/372px-HustlerTV.svg.png',
        'video': 'http://51.15.0.141:88/hustlerhd/tracks-v1a1/mono.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'REDLIGHT TV HD',
        'thumb':
        'https://static.wikia.nocookie.net/tvfanon6528/images/3/39/Redlight_HD_%282010-.n.v.%29.png',
        'video': 'http://51.15.0.141:88/redlightHD/tracks-v1a1/mono.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'FILMON 1 TV',
        'thumb':
        'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
        'video': 'http://www.filmon.com/vr-streams/6152.high/playlist.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'FILMON 2 TV',
        'thumb':
        'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
        'video': 'http://www.filmon.com/vr-streams/6170.high/playlist.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'FILMON 3 TV',
        'thumb':
        'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
        'video': 'http://www.filmon.com/vr-streams/6158.high/playlist.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'FILMON 4 TV',
        'thumb':
        'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
        'video': 'http://www.filmon.com/vr-streams/6155.high/playlist.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'VISIT-X TV',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Offizielles_VISIT-X_Logo.jpg/800px-Offizielles_VISIT-X_Logo.jpg',
        'video': 'http://194.116.150.47:1935/vxtv/live_720p/playlist.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'JASMIN TV',
        'thumb': 'https://www.parsatv.com/index_files/channels/jasmintv.png',
        'video':
        'http://109.71.162.112:1935/live/hd.jasminchannel.stream/playlist.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'BIG TITS TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/bigtits.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'BLOWJOB TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/blowjob.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'TEEN TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/teen.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'COMPILATION TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/compilation.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'CUCKOLD TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/cuckold.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'FETISH TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/fetish.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'GANGBANG TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/gangbang.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'HARDCORE TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/hardcore.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }, {
        'name': 'INTERRACIAL TV',
        'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
        'video': 'http://cdn.adultiptv.net/interracial.m3u8',
        'genre': 'ADULT TV ALTERNATIVE'
    }],
    'EUROPE VOD XXX': [{
        'name': 'Clausura',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/Clausura.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Расстегни ширинку: Путешествие во времени',
        'thumb': '',
        'video':
        'https://video1.tizam.cc/films/rasstegni_shirinku_puteshestvie_vo_vremeni.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Корпоративные Связи',
        'thumb': '',
        'video': 'https://video1.tizam.cc/films/corporate_bonding.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Anal Naya Akademiya',
        'thumb': '',
        'video': 'https://video1.tizam.cc/films/anal_naya_akademiya.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Vlastelin Zadnic',
        'thumb': '',
        'video': 'https://video1.tizam.cc/films/vlastelin_zadnic.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Lyubovnica S Russkim Perevodom',
        'thumb': '',
        'video':
        'https://video1.tizam.cc/films/lyubovnica_s_russkim_perevodom.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Pohotlivye Lakomki',
        'thumb': '',
        'video': 'https://video1.tizam.cc/films/pohotlivye_lakomki.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Chastnyj Matador 4 Anal',
        'thumb': '',
        'video':
        'https://video1.tizam.cc/films/chastnyj_matador_4_anal_nyj_sad.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Anita Dark Forever',
        'thumb': '',
        'video': 'https://video1.tizam.cc/films/anita_dark_navsegda.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Uragan Pustyne',
        'thumb': '',
        'video': 'https://video1.tizam.cc/films/uragan_v_pustyne.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Porochnye Sanitarki',
        'thumb': '',
        'video':
        'https://video1.tizam.cc/films/porochnye_sanitarki_dlya_prokazhennoj_armii.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'La Scelta',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/La-Scelta.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Glamour Girls 2',
        'thumb': '',
        'video': 'https://video1.tizam.cc/vk/GlamourGirls2.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Sex Tapes',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/SexTapes.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Dirty Girls 3',
        'thumb': '',
        'video': 'https://video2.tizam.cc/files/1689550/dirty_girlz_3.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Anal Freedom',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/180AnalFreedom.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Anna Apprentie Soubrette',
        'thumb': '',
        'video':
        'https://video2.tizam.cc/files/2395590/anna_apprentie_soubrette.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Mobsters Ball',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/MobstersBall.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Big Butts Like It Big',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/Big-Butts-Like-it-Big.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Big Butts Like It Big 2',
        'thumb': '',
        'video':
        'https://video1.tizam.cc/old_films/Big-Butts-like-it-Big-2.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Riot Girls',
        'thumb': '',
        'video': 'https://video1.tizam.cc/films/RiotGirls.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Reality 2',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/Reality-2.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Dream Quest',
        'thumb': '',
        'video': 'https://video1.tizam.cc/old_films/DreamQuest.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Anissa Kate The Widow',
        'thumb': '',
        'video':
        'https://video2.tizam.cc/files/2284150/anissa_kate__the_widow.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Lady Of The Rings Porno Parodiya HD',
        'thumb': '',
        'video':
        'https://video2.tizam.cc/files/1188492/lady_of_the_rings_porno_parodiya_hd.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Sex Rebels',
        'thumb': '',
        'video':
        'https://video1.tizam.cc/old_films/PrivateGold70SexRebels.mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'The 8th Day 2009',
        'thumb': '',
        'video':
        'https://video2.tizam.cc/files/1400673/the_8th_day__8_y_den_2009__chast_1..mp4',
        'genre': 'EUROPE VOD XXX'
    }, {
        'name': 'Priznanie Kristi Vsem Dayu',
        'thumb': '',
        'video':
        'https://video2.tizam.cc/files/2101582/priznanie_kristi___vsem_dayu.mp4',
        'genre': 'EUROPE VOD XXX'
    }],
    'PROMO VOD XXX, ADUH ENAK EEH!!!': [{
        'name': '<!--DISARANKAN MENGGUNAKAN ULTRASURF VPN-->',
        'thumb': '',
        'video': '#',
        'genre': ''
    }, {
        'name': 'XXX  Bang ORG 01',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/54399.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'XXX  Bang ORG 02',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/54400.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'XXX  KArmaXXX 01',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/54372.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'XXX  KArmaXXX 02',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/54373.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'XXX  KArmaXXX 03',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/54374.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'XXX  KArmaXXX 04',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/54375.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'BigTitsAtSchool.20.03.15.Bella.Rolland.Old.Man.On.Campus',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50020.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'BabyGotBoobs.20.04.15.Sommer.Isabella.Top.Heavy',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50014.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'PornstarsLikeItBig.20.03.13.Siri.Someone.Called.Siri',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50050.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'PornstarsLikeItBig.20.03.20.Abella.Danger.Dancing.Domme',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50122.mp4',
        'genre': 'VOD XXX'
    }, {
        'name':
        'PornstarsLikeItBig.20.03.22.Madison.Ivy.And.Liv.Wild.A.Wild.Night',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50123.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'PornstarsLikeItBig.20.03.25.Kendra.Sunderland.Dripping.Wet',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50124.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'RealWifeStories.20.03.13.Nicolette.Shea.An.Intense.Affair',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50052.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'TeensLikeItBig.20.03.12.Lala.Ivey.Break.And.Enter.Me',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50054.mp4',
        'genre': 'VOD XXX'
    }, {
        'name': 'BrazzersExxtra.20.04.12.Eliza.Ibarra.Hopping.On.A.Cock',
        'thumb': '',
        'video':
        'http://hmen5.xyz:8000/movie/Nnejatmesci/21082020UHNNB/50076.mp4',
        'genre': 'VOD XXX'
    }],
    'LIVE TV XXX HD': [{
        'name': '<!--DISARANKAN MENGGUNAKAN ULTRASURF VPN-->',
        'thumb': '',
        'video': '#',
        'genre': ''
    }, {
        'name': 'Penthouse Gold TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15890',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Penthouse Quickies TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15891',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Redlight TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15882',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Hustler TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15879',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Blue Hustler TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15897',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Beate Uhse TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15888',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Dorcel FHD TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15914',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Brazzers TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15913',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Private TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15915',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'JapanHDV TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/38045',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'JapanHDV Creampie TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/37947',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'JapanHDV Group TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/37945',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Deep Lush TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/40157',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': '"Moms Teach Sex TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/46984',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Nubiles Porn TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/49349',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Bad Teens Punished TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/49351',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Nubiles Casting TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/49353',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Step Siblings Caught TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/49355',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Princess Cum TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/49357',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Family Pies TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/49359',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Teacher Fucks Teens TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/49361',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Girls Love Girls TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/37937',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Girls Love Girls 2 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/37943',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Teens TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/37942',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Blacked X1 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/39810',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Blacked X2 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/39811',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Tushy TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/39812',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Digital Playground TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/39813',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Reality Kings TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15899',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Evil Angel TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15885',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Dusk TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15878',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Venus TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15895',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'SextoSenso TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15886',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Taboo TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15877',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Hot TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15894',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15881',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Passion XXX TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15880',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'SuperOne TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15900',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Playboy TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/15911',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Vivid Europe TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/16580',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Vivid Red TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/23418',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/17423',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic 2 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/17424',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic 3 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/17425',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic 4 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/17426',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Balkan Erotik TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/19024',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Blue Hustler Europe TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/24905',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Fake Agent TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/25851',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Erox TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/27187',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic 5 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28050',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic 6 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28051',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic 7 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28052',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Pink Erotic 8 TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28053',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Visit-X TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28229',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Shalun (18+) TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/19023',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Meiden Van Holland Hard TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/21521',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Bangerz (18+) TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28868',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Net XX TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28869',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Playhouse TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28870',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'Bang U (18+) TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28875',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'XY Plus TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28854',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'XY Max TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28855',
        'genre': 'LIVE TV ADULT HD'
    }, {
        'name': 'XY Mix TV',
        'thumb': '',
        'video': 'http://tv.iptvstack.net:80/sfiXpDm63/7WVZi28500/28856',
        'genre': 'LIVE TV ADULT HD'
    }]
}


def get_url(**kwargs):

    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_categories():

    return VIDEOS.keys()


def get_videos(category):

    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, 'LIVE TV & VOD')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({
            'thumb': VIDEOS[category][0]['thumb'],
            'icon': VIDEOS[category][0]['thumb'],
            'fanart': VIDEOS[category][0]['thumb']
        })
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': category,
            'genre': category,
            'mediatype': 'video'
        })
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        #url = get_url(action='listing', category=category)
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': video['name'],
            'genre': video['genre'],
            'mediatype': 'video'
        })
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({
            'thumb': video['thumb'],
            'icon': video['thumb'],
            'fanart': video['thumb']
        })
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        #url = get_url(action='play', video=video['video'])
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
