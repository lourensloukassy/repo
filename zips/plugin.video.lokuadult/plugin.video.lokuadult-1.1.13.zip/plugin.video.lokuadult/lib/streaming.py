import xbmc
import sys
import xbmcgui
import xbmcplugin
import os

from lib.resolveurl import ResolveUrl

from lib.resolveurl import ResolveUrl as urlresolver

lokuchannel = 'https://youtu.be/yeWaw-0yj4w'

url = lokuchannel

resolved = urlresolver.resolve(url)

xbmc.Player().play(resolved)