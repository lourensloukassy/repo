import resolveurl
import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

#                      {'name': '',
#                      'thumb': '',
#                      'video': '',
#                      'genre': 'SPORTS'}
#

VIDEOS = {
    'INDONESIAN VIRAL 1': [{
        'name': 'Mango Live 1',
        'thumb': '',
        'video': 'https://dood.la/d/8372q44p96ht',
        'genre': 'Viral 1'
    }, {
        'name': 'ISABELLA',
        'thumb': '',
        'video': 'https://dood.la/d/077fcvvuznhy',
        'genre': 'Viral 1'
    }, {
        'name': 'Ayu Nganjuk',
        'thumb': '',
        'video': 'https://dood.la/d/hum6j9tjodxl',
        'genre': 'Viral 1'
    }, {
        'name': 'Selebgram Hilda Mango Live',
        'thumb': '',
        'video': 'https://dood.la/d/8nkwjvyrw2p5',
        'genre': 'Viral 1'
    }, {
        'name': 'NEXT',
        'thumb': '',
        'video': 'https://dood.la/d/bsgg2t4f5py5',
        'genre': 'Viral 1'
    }, {
        'name': 'Semok dan Gede',
        'thumb': '',
        'video': 'https://dood.la/d/qr7pv2w4xxgz',
        'genre': 'Viral 1'
    }, {
        'name': 'KONTEN DARI OLYFANS',
        'thumb': '',
        'video': 'https://dood.la/d/qago6ebfr2tj',
        'genre': 'Viral 1'
    }, {
        'name': 'BOCIL COLMEK',
        'thumb': '',
        'video': 'https://dood.la/d/ndf98ls2kpow',
        'genre': 'Viral 1'
    }, {
        'name': 'KAKAK PINK',
        'thumb': '',
        'video': 'https://dood.la/d/310p884sedp5',
        'genre': 'Viral 1'
    }, {
        'name': 'BENING',
        'thumb': '',
        'video': 'https://dood.la/d/rardvbb92qgq',
        'genre': 'Viral 1'
    }, {
        'name': 'MANTAP KAKAK',
        'thumb': '',
        'video': 'https://dood.la/d/n0mmp6fm9ydy',
        'genre': 'Viral 1'
    }, {
        'name': 'CINDY LIVE',
        'thumb': '',
        'video': 'https://dood.la/d/iqw6laklpsiz',
        'genre': 'Viral 1'
    }, {
        'name': 'CANTIK TETE GEDE',
        'thumb': '',
        'video': 'https://dood.la/d/dgomq320ymsk',
        'genre': 'Viral 1'
    }, {
        'name': 'GEDE',
        'thumb': '',
        'video': 'https://dood.la/d/fhqc9y45ieps',
        'genre': 'Viral 1'
    }, {
        'name': 'CANTIK TT GEDE PULA',
        'thumb': '',
        'video': 'https://dood.la/d/x8yji6xvgsff',
        'genre': 'Viral 1'
    }, {
        'name': 'MANTAP JUGA INI CEWEK',
        'thumb': '',
        'video': 'https://dood.la/d/leisyqepwq16',
        'genre': 'Viral 1'
    }, {
        'name': 'REMMES AKU SAYANG',
        'thumb': '',
        'video': 'https://dood.la/d/gc6uwu60mxjr',
        'genre': 'Viral 1'
    }, {
        'name': 'TTNYA GEDE BANGET',
        'thumb': '',
        'video': 'https://dood.la/d/9f1sj3v9ibgn',
        'genre': 'Viral 1'
    }, {
        'name': 'SEBELUM PULANG MAIN DULU DI TOILET SEKOLAH',
        'thumb': '',
        'video': 'https://dood.la/d/gvlgfcofdsbz',
        'genre': 'Viral 1'
    }, {
        'name': 'NGEWE DENGAN PACAR',
        'thumb': '',
        'video': 'https://dood.la/d/h6f275osv039',
        'genre': 'Viral 1'
    }, {
        'name': 'SERIUS INI KONTEN BAGUS COLMEK SAMPE BOCOR',
        'thumb': '',
        'video': 'https://dood.la/d/xusqly1397cz',
        'genre': 'Viral 1'
    }],
    'INDONESIAN VIRAL 2': [{
        'name': 'MAIN SAMA DOI SAAT RUMAH SEPI PAPI MAMI PERGI KELUAR NEGERI',
        'thumb': '',
        'video': 'https://dood.la/d/vt3026eqdabl',
        'genre': 'Viral 2'
    }, {
        'name': 'MISS HIJABERS',
        'thumb': '',
        'video': 'https://dood.la/d/t7ie1cabkcz1',
        'genre': 'Viral 2'
    }, {
        'name': 'NOT FOR SALE AYW',
        'thumb': '',
        'video': 'https://dood.so/d/0wzfy80dar16',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw11',
        'thumb': '',
        'video': 'https://dood.la/d/ws85yugrs371',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw1',
        'thumb': '',
        'video': 'https://dood.la/d/3ccllyq9w0hx',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw13',
        'thumb': '',
        'video': 'https://dood.la/d/adiem1fnvf4p',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw15',
        'thumb': '',
        'video': 'https://dood.la/d/dwp9fif5c4iv',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw17',
        'thumb': '',
        'video': 'https://dood.la/d/i6oadlztembg',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw3',
        'thumb': '',
        'video': 'https://dood.la/d/6iy8dt7w0g0t',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw5',
        'thumb': '',
        'video': 'https://dood.la/d/f62350oqd6n9',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw7',
        'thumb': '',
        'video': 'https://dood.la/d/84xe347aadx8',
        'genre': 'Viral 2'
    }, {
        'name': 'TIKA tcwshw9',
        'thumb': '',
        'video': 'https://dood.la/d/vcfe4ptui95r',
        'genre': 'Viral 2'
    }, {
        'name': 'Tika Cantik Bintang Porno Toket Brutal Part 10',
        'thumb': '',
        'video': 'https://dood.la/d/769x40rx54c4',
        'genre': 'Viral 2'
    }, {
        'name': 'Tika Cantik Bintang Porno Toket Brutal Part 12',
        'thumb': '',
        'video': 'https://dood.la/d/s5o0wkgjwraw',
        'genre': 'Viral 2'
    }, {
        'name': 'Tika Cantik Bintang Porno Toket Brutal Part 16',
        'thumb': '',
        'video': 'https://dood.la/d/vu5orbwxsta7',
        'genre': 'Viral 2'
    }, {
        'name': 'Tika Cantik Bintang Porno Toket Brutal Part 2',
        'thumb': '',
        'video': 'https://dood.la/d/o2taxxeagmqd',
        'genre': 'Viral 2'
    }, {
        'name': 'Tika Cantik Bintang Porno Toket Brutal Part 4',
        'thumb': '',
        'video': 'https://dood.la/d/tx29856x33ie',
        'genre': 'Viral 2'
    }, {
        'name': 'Tika Cantik Bintang Porno Toket Brutal Part 6',
        'thumb': '',
        'video': 'https://dood.la/d/c57llpm6tj5c',
        'genre': 'Viral 2'
    }, {
        'name': 'TANTE SEMOK LIVE  CROTT DIKAMAR MANDI',
        'thumb': '',
        'video': 'https://dood.la/d/8e9z5xonv61z',
        'genre': 'Viral 2'
    }, {
        'name': 'LIVE MANDI TTNYA BULAT BODYNYA MONTOXX PARAH',
        'thumb': '',
        'video': 'https://dood.la/d/205vs7b1cbfz',
        'genre': 'Viral 2'
    }, {
        'name': 'CANTIK CANTIK KOK COLMEK PAKEK TIMUN',
        'thumb': '',
        'video': 'https://dood.la/d/0jjoinx3y72b',
        'genre': 'Viral 2'
    }, {
        'name': 'TERGANGBANG PAS PULANG SEKOLAH',
        'thumb': '',
        'video': 'https://dood.la/d/kz37fbojy46k',
        'genre': 'Viral 2'
    }, {
        'name': 'ANISA ABG CANTIK DI SEWA OM OM',
        'thumb': '',
        'video': 'https://dood.la/d/bsxmypifa0b9',
        'genre': 'Viral 2'
    }, {
        'name': 'Kakak Cantik Live Sambil Colmek Dengan 2 Jarinya',
        'thumb': '',
        'video': 'https://dood.la/d/tlm4suggb4xs',
        'genre': 'Viral 2'
    }, {
        'name': 'Cantik Banget Ini Cewek PINK Lagi',
        'thumb': '',
        'video': 'https://dood.la/d/ovod6q8x56bq',
        'genre': 'Viral 2'
    }, {
        'name': 'FELLY ANGELISTA MAIN DALEM MOBIL DENGAN PACAR',
        'thumb': '',
        'video': 'https://dood.la/d/d3smkhsa0at3',
        'genre': 'Viral 2'
    }, {
        'name': 'KONTEN PREMIUM HD',
        'thumb': '',
        'video': 'https://dood.la/d/5yauc843sagb',
        'genre': 'Viral 2'
    }, {
        'name': 'COLMEK CINCINNYA HAMPIR KETINGGALAN DIDALAM',
        'thumb': '',
        'video': 'https://dood.la/d/eznavljczt2a',
        'genre': 'Viral 2'
    }, {
        'name': 'PENTILNYA PINK',
        'thumb': '',
        'video': 'https://dood.la/d/ecx62ex97eq9',
        'genre': 'Viral 2'
    }, {
        'name': 'LIVE SAMBIL MANDI',
        'thumb': '',
        'video': 'https://dood.la/d/r4irwfjpkrx8',
        'genre': 'Viral 2'
    }, {
        'name': 'BERCADAR TAPI GITU',
        'thumb': '',
        'video': 'https://dood.la/d/z5r5lu3g874b',
        'genre': 'Viral 2'
    }, {
        'name': 'SUSTER VIRALL MAIN DI HOTEL',
        'thumb': '',
        'video': 'https://dood.la/d/5htkvtpz01zb',
        'genre': 'Viral 2'
    }, {
        'name': 'VIDEO 15028443479890460966',
        'thumb': '',
        'video': 'https://dood.la/d/p19liavyezyc',
        'genre': 'Viral 2'
    }, {
        'name': 'Koleksi Basah2',
        'thumb': '',
        'video': 'https://dood.la/d/zymaa4qg3d5n',
        'genre': 'Viral 2'
    }, {
        'name': 'VIDEO 56287529403459043987',
        'thumb': '',
        'video': 'https://dood.la/d/j5pqccbp5vcd',
        'genre': 'Viral 2'
    }, {
        'name': 'VIDEO 56239950503078265443',
        'thumb': '',
        'video': 'https://dood.la/d/ebqzpbjos8j0',
        'genre': 'Viral 2'
    }, {
        'name': 'VIDEO 15147925870882586965',
        'thumb': '',
        'video': 'https://dood.la/d/2ovqidaygkg9',
        'genre': 'Viral 2'
    }],
    'INDONESIAN VIRAL 3': [{
        'name': 'VIDEO LIVE 1',
        'thumb': '',
        'video': 'https://dood.la/d/bblyqv6h1l36',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 2',
        'thumb': '',
        'video': 'https://dood.la/d/qh82ifc8mtmg',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 3',
        'thumb': '',
        'video': 'https://dood.la/d/92q5spoqsi0h',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 4',
        'thumb': '',
        'video': 'https://dood.la/d/echu9vvml1op',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 5',
        'thumb': '',
        'video': 'https://dood.la/d/ke4xj5nwpfgd',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 6',
        'thumb': '',
        'video': 'https://dood.la/d/ki3clttf8b07',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 7',
        'thumb': '',
        'video': 'https://dood.la/d/4mssbhvfo95e',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 8',
        'thumb': '',
        'video': 'https://dood.la/d/t2jzzkzht9d9',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 9',
        'thumb': '',
        'video': 'https://dood.la/d/u2fq106xotch',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 10',
        'thumb': '',
        'video': 'https://dood.la/d/mgai5i9wguqw',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 11',
        'thumb': '',
        'video': 'https://dood.la/d/6d4fj2kt0abd',
        'genre': 'Viral 3'
    }, {
        'name': 'GOJEK VIRAL',
        'thumb': '',
        'video': 'https://dood.la/d/b53gf818gd9n',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 12',
        'thumb': '',
        'video': 'https://dood.la/d/zql7hclmll3u',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 13',
        'thumb': '',
        'video': 'https://dood.la/d/74r8iq7zt1pq',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 14',
        'thumb': '',
        'video': 'https://dood.la/d/u781q80500r7',
        'genre': 'Viral 3'
    }, {
        'name': 'PRANK TEKNISI KULKAS',
        'thumb': '',
        'video': 'https://dood.la/d/okxbgecut3n0',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 15',
        'thumb': '',
        'video': 'https://dood.la/d/9fuu9am2x189',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 16',
        'thumb': '',
        'video': 'https://dood.la/d/uxm6gtjck9re',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 17',
        'thumb': '',
        'video': 'https://dood.la/d/ami14i1mknux',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 18',
        'thumb': '',
        'video': 'https://dood.la/d/jutgu852u7wf',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 19',
        'thumb': '',
        'video': 'https://dood.la/d/l5vjzzotdhjx',
        'genre': 'Viral 3'
    }, {
        'name': 'VIDEO LIVE 20',
        'thumb': '',
        'video': 'https://dood.la/d/fyg1ux8ki33k',
        'genre': 'Viral 3'
    }],
    'INDONESIAN VIRAL 4': [{
        'name': 'VIDEO LIVE 21',
        'thumb': '',
        'video': 'https://dood.la/d/s7dix406taoj',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 22',
        'thumb': '',
        'video': 'https://dood.la/d/3z56q6a789nl',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 23',
        'thumb': '',
        'video': 'https://dood.la/d/phes0p091an3',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 24',
        'thumb': '',
        'video': 'https://dood.la/d/zqc0rf32l4mm',
        'genre': 'Viral 4'
    }, {
        'name': 'SRI AYU TANIA',
        'thumb': '',
        'video': 'https://dood.la/d/l1se7s461nmt',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 25',
        'thumb': '',
        'video': 'https://dood.la/d/4gdvmorlkrgj',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 26',
        'thumb': '',
        'video': 'https://dood.la/d/i2ez73gkw8yf',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 27',
        'thumb': '',
        'video': 'https://dood.la/d/eaipenah198h',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 28',
        'thumb': '',
        'video': 'https://dood.la/d/v9y1k1ecri6o',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 29',
        'thumb': '',
        'video': 'https://dood.la/d/tfieshl4r1uu',
        'genre': 'Viral 4'
    }, {
        'name': 'LIVE BARENG ANAK KECIL',
        'thumb': '',
        'video': 'https://dood.la/d/n7fk4ghqbwt8',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 30',
        'thumb': '',
        'video': 'https://dood.la/d/tyq5vplspkag',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 31',
        'thumb': '',
        'video': 'http://dood.to/d/jzetgiyh6ag0',
        'genre': 'Viral 4'
    }, {
        'name': 'HIJABBERS LAGI',
        'thumb': '',
        'video': 'https://dood.la/d/vumnz6ci4kuy',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 32',
        'thumb': '',
        'video': 'https://dood.la/d/wu0k0i2re1xx',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 33',
        'thumb': '',
        'video': 'https://dood.la/d/rzfe0n5jdt4g',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 34',
        'thumb': '',
        'video': 'https://dood.la/d/c268hrfyrpui',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 35',
        'thumb': '',
        'video': 'https://dood.la/d/6krffkmj6l6u',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 36',
        'thumb': '',
        'video': 'https://dood.la/d/vey7tbbjepfr',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 37',
        'thumb': '',
        'video': 'https://dood.la/d/j2kvdbnhyicy',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 38',
        'thumb': '',
        'video': 'https://dood.la/d/6nlxbpefiyj6',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 39',
        'thumb': '',
        'video': 'https://dood.la/d/gzbjpzhc06j4',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 40',
        'thumb': '',
        'video': 'https://dood.la/d/fybu76bv78lr',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 41',
        'thumb': '',
        'video': 'https://dood.la/d/ds2nhivjhk4z',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 42',
        'thumb': '',
        'video': 'https://dood.la/d/htt5b510jhcw',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 43',
        'thumb': '',
        'video': 'https://dood.la/d/gm8do299hyup',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 44',
        'thumb': '',
        'video': 'https://dood.la/d/3ckgxayyduko',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 45',
        'thumb': '',
        'video': 'https://dood.la/d/suefu1lfm8n8',
        'genre': 'Viral 4'
    }, {
        'name': 'VIDEO LIVE 46',
        'thumb': '',
        'video': 'https://dood.la/d/vegp93zapvz0',
        'genre': 'Viral 4'
    }, {
        'name': 'MASUKIN TERONG KE MEMEKNYA ENAK BANGETTT YA BUNDD',
        'thumb': '',
        'video': 'https://dood.la/d/7jt7qqhhc8j8',
        'genre': 'Viral 4'
    }, {
        'name': 'LIVE NONTON BOLA SAMBIL NGEWE',
        'thumb': '',
        'video': 'http://dood.to/d/3m5t87djulq3',
        'genre': 'Viral 4'
    }]
}


def get_url(**kwargs):

    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_categories():

    return VIDEOS.keys()


def get_videos(category):

    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """

    xbmcplugin.setPluginCategory(_HANDLE, 'INDONESIAN VIRAL XXX')

    xbmcplugin.setContent(_HANDLE, 'videos')

    categories = get_categories()

    for category in categories:

        list_item = xbmcgui.ListItem(label=category)

        list_item.setArt({
            'thumb': VIDEOS[category][0]['thumb'],
            'icon': VIDEOS[category][0]['thumb'],
            'fanart': VIDEOS[category][0]['thumb']
        })
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': category,
            'genre': category,
            'mediatype': 'video'
        })
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        #url = get_url(action='listing', category=category)
        url = get_url(action='listing', category=category)

        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': video['name'],
            'genre': video['genre'],
            'mediatype': 'video'
        })
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({
            'thumb': video['thumb'],
            'icon': video['thumb'],
            'fanart': video['thumb']
        })
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        #url = get_url(action='play', video=video['video'])
        # Add our item to the Kodi virtual folder listing.
        if resolveurl.HostedMediaFile(video['video']):
            resolved = resolveurl.resolve(video['video'])

        url = get_url(action='play', video=resolved)
        is_folder = False
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """

    play_item = xbmcgui.ListItem(path=path)

    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """

    params = dict(parse_qsl(paramstring))

    if params:
        if params['action'] == 'listing':

            list_videos(params['category'])
        elif params['action'] == 'play':
            play_video(params['video'])
        else:

            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:

        list_categories()


if __name__ == '__main__':

    router(sys.argv[2][1:])
