import xbmc
import resolveurl as urlresolver
import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin
from lib import channel

# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

#                      {'name': '',
#                      'thumb': '',
#                      'video': '',
#                      'genre': 'SPORTS'}
#

VIDEOS = channel.lokuindoadult


def get_url(**kwargs):

    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_categories():

    return VIDEOS.keys()


def get_videos(category):

    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """

    xbmcplugin.setPluginCategory(_HANDLE, 'INDONESIAN VIRAL XXX')

    xbmcplugin.setContent(_HANDLE, 'videos')

    categories = get_categories()

    for category in categories:

        list_item = xbmcgui.ListItem(label=category)

        list_item.setArt({
            'thumb': VIDEOS[category][0]['thumb'],
            'icon': VIDEOS[category][0]['thumb'],
            'fanart': VIDEOS[category][0]['thumb']
        })
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': category,
            'genre': category,
            'mediatype': 'video'
        })
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        #url = get_url(action='listing', category=category)
        url = get_url(action='listing', category=category)

        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': video['name'],
            'genre': video['genre'],
            'mediatype': 'video'
        })
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({
            'thumb': video['thumb'],
            'icon': video['thumb'],
            'fanart': video['thumb']
        })
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        #url = get_url(action='play', video=video['video'])
        # Add our item to the Kodi virtual folder listing.
        #if resolveurl.HostedMediaFile(video['video']):
        #    resolved = resolveurl.resolve(video['video'])

        url = get_url(action='play', video=video['video'])
        is_folder = False

        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """

    play_item = xbmcgui.ListItem(path=path)

    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """

    params = dict(parse_qsl(paramstring))

    if params:
        if params['action'] == 'listing':

            list_videos(params['category'])
        elif params['action'] == 'play':
            play_video(urlresolver.resolve(params['video']))
        else:

            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:

        list_categories()


if __name__ == '__main__':

    router(sys.argv[2][1:])
