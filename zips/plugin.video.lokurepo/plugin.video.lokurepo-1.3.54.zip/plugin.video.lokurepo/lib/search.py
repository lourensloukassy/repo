import sys
from urllib import urlencode
from urllib import quote
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin
import xbmc

_url = sys.argv[0]

_handle = int(sys.argv[1])

CATEGORIES = ["Recently Added", "Search"]


def get_user_input():
    kb = xbmc.Keyboard('', 'Please enter the video title')
    kb.doModal()  # Onscreen keyboard appears
    if not kb.isConfirmed():
        return
    query = kb.getText()  # User input
    return query


def get_url(**kwargs):

    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():

    return CATEGORIES


def create_video_list(url):

    videos = []

    return videos


def get_videos(category):

    if category == "Recently Added":
        url = "http://somewebsite.com/recent/"
        videos = create_video_list(url)
        return videos
    elif category == "Search":
        query = get_user_input()
        if not query:
            return []
        url = "http://somewebsite.com/results/?query={}".format(quote(query))
        videos = create_video_list(url)
        return videos


def list_categories():

    categories = get_categories()

    for category in categories:

        list_item = xbmcgui.ListItem(label=category)

        list_item.setInfo('video', {'title': category, 'genre': category})

        url = get_url(action='listing', category=category)

        is_folder = True

        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)

    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):

    videos = get_videos(category)

    for video in videos:

        list_item = xbmcgui.ListItem(label=video['name'])

        list_item.setInfo('video', {
            'title': video['name'],
            'genre': video['genre'],
            'plot': video['plot']
        })

        list_item.setArt({
            'thumb': video['thumb'],
            'icon': video['thumb'],
            'fanart': video['thumb']
        })

        list_item.setProperty('IsPlayable', 'true')

        url = get_url(action='play', video=video['video'])

        is_folder = False

        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)

    xbmcplugin.endOfDirectory(_handle)


def play_video(path):

    play_item = xbmcgui.ListItem(path=path)

    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):

    params = dict(parse_qsl(paramstring))

    if params:
        if params['action'] == 'listing':

            list_videos(params['category'])
        elif params['action'] == 'play':

            play_video(params['video'])
        else:

            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:

        list_categories()


if __name__ == '__main__':

    router(sys.argv[2][1:])