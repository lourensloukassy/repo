import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin
# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

#                      {'name': '',
#                      'thumb': '',
#                      'video': '',
#                      'genre': 'SPORTS'}
#

VIDEOS = {'JAPAN VOD': 
                     [{'name': 'EBOD-399 初拍，J罩杯111cm的巨乳少女 七草千岁',
                       'thumb': 'http://img.gjtjjp.com/2017-11/DUT4GCW399.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171030/DUT4GCW399/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'JUFD-378 爆乳美女遭遇色狼 不断堕落的美女秘书',
                       'thumb': 'http://img.gjtjjp.com/2017-11/DVM8JYR378.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171030/DVM8JYR378/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'SDDE-365 客房！美食！露天！！一面吸吮天上掉下来的肉棒一面在人气温泉旅馆内泡汤...甚至还一面作爱！！',
                       'thumb': 'http://img.gjtjjp.com/2017-11/EJH6CXI365.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171030/EJH6CXI365/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'SHE-095 素人比基尼辣妹对大肉棒兴奋不已!! 海岸潮吹搭讪 九十九里篇',
                       'thumb': 'http://img.gjtjjp.com/2017-11/EDT5UKM095.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171030/EDT5UKM095/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'GVG-461 最喜欢巨乳的正太的变态恶作剧 三岛奈津子',
                       'thumb': 'http://img.gjtjjp.com/2017-11/GJL9EBT461.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/GJL9EBT461/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'DVDMS-160 一般男女实验AV 单向玻璃对面是最爱的女友！能看着她被其他男人干到最后就有100万日元！巨乳女友不知道男友在看沉迷于30cm巨根！',
                       'thumb': 'http://img.gjtjjp.com/2017-11/SJEB4TKM160.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/SJEB4TKM160/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'GETS-054 让一直自以为是的不良少年喝下女体化春药，让他变成一个淫蕩女人',
                       'thumb': 'http://img.gjtjjp.com/2017-11/SJR3YLO054.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/SJR3YLO054/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'KUSR-034 公司里人见人爱 美女秘书巨乳紧缚',
                       'thumb': 'http://img.gjtjjp.com/2017-11/RTO7VKD034.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/RTO7VKD034/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'AP-469 公厕美女清洁员体内放尿中出痴汉',
                       'thumb': 'http://img.gjtjjp.com/2017-11/PKE5TH469.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/PKE5TH469/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                      {'name': 'PRED-006 后仰潮喷射 绝顶中出按摩店 樱井彩',
                       'thumb': 'http://img.gjtjjp.com/2017-11/DJE8GHO006.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/DJE8GHO006/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'SHE-468 按摩女的玉手让下体不由自主的勃起硬起来，直接不带套内射！ 21',
                       'thumb': 'http://img.gjtjjp.com/2017-11/EJT4HYO468.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/EJT4HYO468/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'PPPD-590 巨乳女老师的诱惑 香椎梨亚',
                       'thumb': 'http://img.gjtjjp.com/2017-11/DSN0JKQ590.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/DSN0JKQ590/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'CMD-008 诱惑◆按摩沙龙 麻里梨夏',
                       'thumb': 'http://img.gjtjjp.com/2017-11/DA8JKE008.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/DA8JKE008/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'PRED-017 就算快乐到失禁也绝不结束的穷兇极恶胖子的强力交尾 佐佐木明希',
                       'thumb': 'http://img.gjtjjp.com/2017-11/DJ9RHY017.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/DJ9RHY017/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'HUNTA-348 穿着小号泳衣的巨乳年轻人妻去旅行露出乳房，下乳让人挪不开目光超兴奋！',
                       'thumb': 'http://img.gjtjjp.com/2017-11/AJ2RHY348.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/AJ2RHY348/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'EBOD-591 舞蹈曆10年培养出来的惊人身材和扭腰！！九州超有名偶像组合前成员竟然AV出道！！ 松冈美绪',
                       'thumb': 'http://img.gjtjjp.com/2017-11/DFGJ9LOR591.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/DFGJ9LOR591/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'VOSS-046 家里一直都很贫穷 从小学到高中的外号一直都是穷鬼的我靠着奖学金上了大学，为了赚钱在麵包店打工 对一个巨乳太太一见锺情！',
                       'thumb': 'http://img.gjtjjp.com/2017-11/SJKL3TRY046.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/SJKL3TRY046/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'YST-120 我被胁迫了 古川祥子',
                       'thumb': 'http://img.gjtjjp.com/2017-11/TJKE6BGT120.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/TJKE6BGT120/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'MMYM-008 完美的丰臀美女 莲实克蕾雅 小姐主演',
                       'thumb': 'http://img.gjtjjp.com/2017-11/MBE0FK008.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/MBE0FK008/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'SDMU-675 女人高潮快感是男人的10倍！完全主观 女人视角看自己的身体不停高潮！全是女人的顺从女同女生宿舍',
                       'thumb': 'http://img.gjtjjp.com/2017-11/UJEG6TKO675.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/UJEG6TKO675/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'MMOK-002 淫蕩身体巨乳女开始搬家打工',
                       'thumb': 'http://img.gjtjjp.com/2017-11/KHW5TJL002.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/KHW5TJL002/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'JKSR-302 「比起玩手机更喜欢玩小穴...（羞）」天然F罩杯巨乳妻搭讪性交 真绪',
                       'thumb': 'http://img.gjtjjp.com/2017-11/RHK3OET302.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/RHK3OET302/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'},
                       {'name': 'MIAE-107 双重快感！执拗舔乳头＆快速手淫 波木遥',
                       'thumb': 'http://img.gjtjjp.com/2017-11/EQM3JKDF107.jpg',
                       'video': 'http://video.feimanzb.com:8091/20171103/EQM3JKDF107/550kb/hls/index.m3u8',
                       'genre': 'JAPAN VOD XXX'}
                      ],
        'LIVE TV XXX': [{'name': '<!--DISARANKAN MENGGUNAKAN ULTRASURF VPN-->',
                      'thumb': '',
                      'video': '',
                      'genre': ''},
                      {'name': 'Xhamster Gold TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/75/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                     {'name': 'Blacked TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/17/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                     {'name': 'XL Time',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/8/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                     {'name': 'Public Agent TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/35/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                     {'name': 'Sextury HD TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/61/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': '21 Naturals TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/67/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'MixedX 1 TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/101/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Brazzers TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/5/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Bang Bros TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/21/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                     {'name': 'Vixen TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/15/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                     {'name': 'Tushy TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/22/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Jav Hub TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/44/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Reality Kings TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/4/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Babes TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/23/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Young Sex Parties TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/83/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'MixedX 2 TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/102/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'MixedX 3 TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/103/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'MixedX 4 TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/104/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'MixedX 5 TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/105/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'XCzech TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/31/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'XConfessions TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/73/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Wicked TV',
                      'thumb': '',
                      'video': 'http://iptv.xprime.one/r/28/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Twistys TV',
                      'thumb': '',
                      'video': 'http://ua.xprimetv.com/r/1/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Teeny Lovers TV',
                      'thumb': '',
                      'video': 'http://ua.xprimetv.com/r/54/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Sweetheart Video TV',
                      'thumb': '',
                      'video': 'http://ua.xprimetv.com/r/56/index.m3u8',
                      'genre': 'LIVE TV XXX'},
                      {'name': 'Sweet Sinner TV',
                      'thumb': '',
                      'video': 'http://ua.xprimetv.com/r/55/index.m3u8',
                      'genre': 'LIVE TV XXX'}
                         
                     ],
'EURO 2020 UNOFFICIAL': [{'name': 'BEIN SPORTS 4 MAX',
                      'thumb': 'https://static.wikia.nocookie.net/logopedia/images/d/d0/Logo-bein-sports-max-4-hd_1ut2dcsfzw7zj1204z6hz3qkhp-1-.jpg',
                      'video': 'http://stream.tvtap.live:8081/live/fr-beinmax4.stream/playlist.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'BEIN SPORTS 5 MAX',
                      'thumb': 'https://static.wikia.nocookie.net/logopedia/images/d/d0/Bein-sports-max-5_uioihjesc6nw1p6ydjpmkhsr6-1-.jpg',
                      'video': 'http://stream.tvtap.live:8081/live/fr-beinmax5.stream/playlist.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'BEIN SPORTS 6 MAX',
                      'thumb': 'https://static.wikia.nocookie.net/logopedia/images/c/c7/BE_IN_SPORT_MAX_6_HD_2017.jpg',
                      'video': 'http://stream.tvtap.live:8081/live/fr-beinmax6.stream/playlist.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'BEIN SPORTS 7 MAX',
                      'thumb': 'https://static.wikia.nocookie.net/logopedia/images/b/bd/BE_IN_SPORT_MAX_7_HD_2017.jpg',
                      'video': 'http://stream.tvtap.live:8081/live/fr-beinmax7.stream/playlist.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},                      
                      {'name': 'iTV Sports',
                      'thumb': 'https://i.imgur.com/SsgOgRF.png',
                      'video': 'https://sportportal1.akamaized.net/hls/live/702646/itvlive/ITV1PORTAL2/master.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'iTV (720)',
                      'thumb': 'https://i.imgur.com/SsgOgRF.png',
                      'video': 'http://sportportal1.akamaized.net/hls/live/702646/itvlive/ITV1PORTAL2/master_Main600.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'iTV (1080)',
                      'thumb': 'https://i.imgur.com/SsgOgRF.png',
                      'video': 'http://sportportal1.akamaized.net/hls/live/702646/itvlive/ITV1PORTAL2/master_Main1800.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'SPORTTV 1 HD',
                      'thumb': 'https://www.thesportsdb.com/images/media/logo/qpyqws1470407526.png',
                      'video': 'http://77.83.117.60:8888/02_SPORTTV_1_720p/chunklist.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'TSN',
                      'thumb': 'https://www.pngitem.com/pimgs/m/643-6431333_tsn-transparent-tsn-logo-hd-png-download.png',
                      'video': 'http://157.245.130.174/live/ovo1/chunks.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'},
                      {'name': 'TNT 2 (Brasil)',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/TNT_%28TV_Channel%29.svg/600px-TNT_%28TV_Channel%29.svg.png',
                      'video': 'https://glxlmn026c.singularcdn.net.br/playout_02/playlist-720p.m3u8',
                      'genre': 'EURO 2020 UNOFFICIAL'}     
                     ],
'SPORTS': [{'name': 'BEIN SPORTS ENGLISH 1 HD',
                      'thumb': 'https://i.imgur.com/O0JJEna.png',
                      'video': 'http://77.83.117.60:8888/02_epl1_720p_UK/chunklist.m3u8',
                      'genre': 'SPORTS'},
                     {'name': 'BEIN SPORTS ENGLISH 2 HD',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/c/c9/Logo_bein_sports_2.png',
                      'video': 'http://77.83.117.60:8888/02_epl2_720p_UK/chunklist.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'ESPN 2',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Espn2.svg/1280px-Espn2.svg.png',
                      'video': 'https://gma2.blab.email/espn2.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'BEIN SPORTS 1 ARABIC',
                      'thumb': 'https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS1_DIGITAL_Mono.png',
                      'video': 'http://ferrarico.referrari.com/live/60091_.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'BEIN SPORTS 2 ARABIC',
                      'thumb': 'https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS2_DIGITAL_Mono.png',
                      'video': 'http://ferrarico.referrari.com/live/60092_.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'BEIN SPORTS 3 ARABIC',
                      'thumb': 'https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS3_DIGITAL_Mono.png',
                      'video': 'http://ferrarico.referrari.com/live/60093_.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'NBCSN HD',
                      'thumb': 'https://www.pngfind.com/pngs/m/219-2193037_nbc-sports-nbcsn-boston-hd-png-download.png',
                      'video': 'http://stream.tvtap.live:8081/live/nbcsn.stream/playlist.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'SKYNET SPORT HD',
                      'thumb': 'https://2.bp.blogspot.com/-M-nmvvoZ4BQ/W-ovqYaU13I/AAAAAAAAAxM/lYY2Ci2kYuMng3C2lz7SMWDkRn-GmzA5wCK4BGAYYCw/s1600/sky_net_sports_mm_hd.png',
                      'video': 'http://77.83.117.60:8888/03_skynetsporthd_720p/chunklist.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'FOX SPORTS 1 HD',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Fox_Sports_1_logo.svg/1280px-Fox_Sports_1_logo.svg.png',
                      'video': 'https://austchannel-live.akamaized.net/hls/live/2002736/austchannel-sport/master.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'BT SPORTS 1 HD',
                      'thumb': 'https://www.thesportsdb.com/images/media/logo/4osx7y1579351981.png',
                      'video': 'http://stream.tvtap.live:8081/live/bt1.stream/playlist.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'BT SPORTS 2 HD',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/1/17/BTSPORT_2_BLACK_RGB.png',
                      'video': 'http://stream.tvtap.live:8081/live/bt220.stream/playlist.m3u8',
                      'genre': 'SPORTS'},
                      {'name': 'BT SPORTS 3 HD',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/4/42/BTSPORT_3_BLACK_RGB.png',
                      'video': 'http://stream.tvtap.live:8081/live/bt33.stream/playlist.m3u8',
                      'genre': 'SPORTS'}  
                      ],
'COPA AMERICA UNOFFICAL': [{'name': 'SPORT TV 2 HD',
                      'thumb': 'https://www.thesportsdb.com/images/media/logo/qpyrpq1470407606.png',
                      'video': 'http://77.83.117.60:8888/02_SPORTTV_2_720p/chunklist.m3u8',
                      'genre': 'COPA AMERICA UNOFFICAL'},
                      {'name': 'SPORT TV 3 HD',
                      'thumb': 'https://www.thesportsdb.com/images/media/logo/xysrvw1470407766.png',
                      'video': 'http://77.83.117.60:8888/02_SPORTTV_3_720p/chunklist.m3u8',
                      'genre': 'COPA AMERICA UNOFFICAL'}  
                     ],
'ADULT TV ALTERNATIVE': [{'name': 'ANAL TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/anal.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'ASIAN TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/asian.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'BIG ASS TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/bigass.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'BIG DICK TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/bigdick.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'BRUNETTE TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://play.iptvxxx.net/brunette.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'BLONDE TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://play.iptvxxx.net/blonde.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'LEO TV',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/7/7f/Leo_TV.png',
                      'video': 'http://213.151.233.20:8000/dna-6233-tv-pc/hls/4004v105.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'HUSTLER TV HD',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/HustlerTV.svg/372px-HustlerTV.svg.png',
                      'video': 'http://51.15.0.141:88/hustlerhd/tracks-v1a1/mono.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'REDLIGHT TV HD',
                      'thumb': 'https://static.wikia.nocookie.net/tvfanon6528/images/3/39/Redlight_HD_%282010-.n.v.%29.png',
                      'video': 'http://51.15.0.141:88/redlightHD/tracks-v1a1/mono.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'FILMON 1 TV',
                      'thumb': 'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
                      'video': 'http://www.filmon.com/vr-streams/6152.high/playlist.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'FILMON 2 TV',
                      'thumb': 'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
                      'video': 'http://www.filmon.com/vr-streams/6170.high/playlist.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'FILMON 3 TV',
                      'thumb': 'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
                      'video': 'http://www.filmon.com/vr-streams/6158.high/playlist.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'FILMON 4 TV',
                      'thumb': 'https://mb.cision.com/Public/3222/9393681/831c225b4269f6db_800x800ar.png',
                      'video': 'http://www.filmon.com/vr-streams/6155.high/playlist.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'VISIT-X TV',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Offizielles_VISIT-X_Logo.jpg/800px-Offizielles_VISIT-X_Logo.jpg',
                      'video': 'http://194.116.150.47:1935/vxtv/live_720p/playlist.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'JASMIN TV',
                      'thumb': 'https://www.parsatv.com/index_files/channels/jasmintv.png',
                      'video': 'http://109.71.162.112:1935/live/hd.jasminchannel.stream/playlist.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'BIG TITS TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/bigtits.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'BLOWJOB TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/blowjob.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'TEEN TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/teen.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'COMPILATION TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/compilation.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'CUCKOLD TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/cuckold.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'FETISH TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/fetish.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'GANGBANG TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/gangbang.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'HARDCORE TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/hardcore.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'},
                      {'name': 'INTERRACIAL TV',
                      'thumb': 'https://files.adultiptv.net/adultiptvnet.jpg',
                      'video': 'http://cdn.adultiptv.net/interracial.m3u8',
                      'genre': 'ADULT TV ALTERNATIVE'}                      
                     ],
'EUROPE VOD': [{'name': 'Clausura',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/Clausura.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Расстегни ширинку: Путешествие во времени',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/rasstegni_shirinku_puteshestvie_vo_vremeni.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Корпоративные Связи',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/corporate_bonding.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Anal Naya Akademiya',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/anal_naya_akademiya.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Vlastelin Zadnic',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/vlastelin_zadnic.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Lyubovnica S Russkim Perevodom',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/lyubovnica_s_russkim_perevodom.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Pohotlivye Lakomki',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/pohotlivye_lakomki.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Chastnyj Matador 4 Anal',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/chastnyj_matador_4_anal_nyj_sad.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Anita Dark Forever',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/anita_dark_navsegda.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Uragan Pustyne',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/uragan_v_pustyne.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Porochnye Sanitarki',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/porochnye_sanitarki_dlya_prokazhennoj_armii.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'La Scelta',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/La-Scelta.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Glamour Girls 2',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/vk/GlamourGirls2.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Sex Tapes',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/SexTapes.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Dirty Girls 3',
                      'thumb': '',
                      'video': 'https://video2.tizam.cc/files/1689550/dirty_girlz_3.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Anal Freedom',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/180AnalFreedom.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Anna Apprentie Soubrette',
                      'thumb': '',
                      'video': 'https://video2.tizam.cc/files/2395590/anna_apprentie_soubrette.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Mobsters Ball',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/MobstersBall.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Big Butts Like It Big',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/Big-Butts-Like-it-Big.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Big Butts Like It Big 2',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/Big-Butts-like-it-Big-2.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Riot Girls',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/films/RiotGirls.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Reality 2',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/Reality-2.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Dream Quest',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/DreamQuest.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Anissa Kate The Widow',
                      'thumb': '',
                      'video': 'https://video2.tizam.cc/files/2284150/anissa_kate__the_widow.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Lady Of The Rings Porno Parodiya HD',
                      'thumb': '',
                      'video': 'https://video2.tizam.cc/files/1188492/lady_of_the_rings_porno_parodiya_hd.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Sex Rebels',
                      'thumb': '',
                      'video': 'https://video1.tizam.cc/old_films/PrivateGold70SexRebels.mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'The 8th Day 2009',
                      'thumb': '',
                      'video': 'https://video2.tizam.cc/files/1400673/the_8th_day__8_y_den_2009__chast_1..mp4',
                      'genre': 'EUROPE VOD'},
                      {'name': 'Priznanie Kristi Vsem Dayu',
                      'thumb': '',
                      'video': 'https://video2.tizam.cc/files/2101582/priznanie_kristi___vsem_dayu.mp4',
                      'genre': 'EUROPE VOD'}
                      ],
'TV JAPAN': [{'name': 'Animax',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Animax.svg/1200px-Animax.svg.png',
                      'video': 'https://redlabmcdn.s.llnwi.net/jp01/bs14/tracks-v1a1/mono.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'Animax (Indonesia)',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Animax.svg/1200px-Animax.svg.png',
                      'video': 'http://210.210.155.35/dr9445/h/h02/01.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'AT-X',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/AT-X_logo.svg/1200px-AT-X_logo.svg.png',
                      'video': 'https://sub2.neetball.net/live/neet.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'Bloomberg TV Asia',
                      'thumb': 'https://www.logolynx.com/images/logolynx/97/97553a1190d11e7536d169f9c2729457.png',
                      'video': 'https://liveprodapnortheast.global.ssl.fastly.net/btv/desktop/ap_live.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'BS Asahi',
                      'thumb': 'https://company.tv-asahi.co.jp/saiyo/group/img/company/logo-bsasahi.png',
                      'video': 'http://203.162.235.41:16914',
                      'genre': 'TV JAPAN'},
                      {'name': 'BS Fuji',
                      'thumb': 'https://www.zne-iptv.com/wp-content/uploads/2017/10/22-BS-FUJI-770x480.jpg',
                      'video': 'http://203.162.235.41:16911',
                      'genre': 'TV JAPAN'},
                      {'name': 'BS TV Tokyo',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TV_Tokyo_logo_20110629.svg/1280px-TV_Tokyo_logo_20110629.svg.png',
                      'video': 'http://203.162.235.41:16915',
                      'genre': 'TV JAPAN'},
                      {'name': 'BS 日テレ',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/BS4_logo.svg/400px-BS4_logo.svg.png',
                      'video': 'http://203.162.235.41:16912',
                      'genre': 'TV JAPAN'},
                      {'name': 'BS-TBS',
                      'thumb': 'https://pbs.twimg.com/profile_images/1260862250295812096/a6-UyLc__400x400.jpg',
                      'video': 'http://203.162.235.41:16913',
                      'genre': 'TV JAPAN'},
                      {'name': 'CGNTV Japan',
                      'thumb': 'https://i.imgur.com/rXrSsiI.jpg',
                      'video': 'http://cgntv-glive.ofsdelivery.net/live/_definst_/cgntv_jp/playlist.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'Channel V',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Channel_V_Logo.svg/1200px-Channel_V_Logo.svg.png',
                      'video': 'rtmp://ivi.bupt.edu.cn:1935/livetv/channelv',
                      'genre': 'TV JAPAN'},
                      {'name': 'Disney Channel Japan',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Disney_channel_2019.png/200px-Disney_channel_2019.png',
                      'video': 'http://redlabmcdn.s.llnwi.net/jp01/bs13/index.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'Fuji TV',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/fr/thumb/6/65/Fuji_TV_Logo.svg/1049px-Fuji_TV_Logo.svg.png',
                      'video': 'http://203.162.235.41:16904',
                      'genre': 'TV JAPAN'},
                      {'name': 'GSTV',
                      'thumb': 'https://i.imgur.com/8AM9fC8.jpg',
                      'video': 'https://gemstv.wide-stream.net/gemstv01/smil:gemstv01.smil/chunklist.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'GTN Typhome (English)',
                      'thumb': 'https://i.imgur.com/gFKvgAd.jpg',
                      'video': 'https://gorilla.gaki-no-tsukai.eu/hls/test.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'GUNMA TV',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Gtv_logo_ja_01.svg/800px-Gtv_logo_ja_01.svg.png',
                      'video': 'https://movie.mcas.jp/switcher/smil:mcas8.smil/master.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'Hiroshima Weather Information',
                      'thumb': 'https://i.imgur.com/ZoYNgdd.png',
                      'video': 'https://hiroshima-tv-live.hls.wselive.stream.ne.jp/hiroshima-tv-live/live/playlist.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'Japan Channel DX',
                      'thumb': 'https://img.japanet.co.jp/shopping/img/senqua/header/logo.gif',
                      'video': 'https://bcsecurelivehls-i.akamaihd.net/hls/live/265320/5043843989001/140130JTDX/index.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'JSTV 2',
                      'thumb': 'https://www.monpetitforfait.com/comparateur-box-internet/wp-content/uploads/2020/05/jstv2-regarder.png',
                      'video': 'http://203.162.235.41:16901',
                      'genre': 'TV JAPAN'},
                      {'name': 'MX Live (Webcam)',
                      'thumb': 'https://i.imgur.com/WLgD1v7.png',
                      'video': 'https://movie.mcas.jp/mcas/mx_live_2/master.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'MX 1 JAPAN',
                      'thumb': 'https://static.wikia.nocookie.net/logopedia/images/5/5f/566456.jpg',
                      'video': 'https://movie.mcas.jp/mcas/mx1_2/chunklist.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'MX 2 JAPAN',
                      'thumb': 'https://static.wikia.nocookie.net/logopedia/images/9/93/52323.jpg',
                      'video': 'https://movie.mcas.jp/mcas/mx2_2/chunklist.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK BS Premium (BS103)',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/2/21/NHK_BS%E3%83%97%E3%83%AC%E3%83%9F%E3%82%A2%E3%83%A0_%E6%96%B0%E3%83%AD%E3%82%B4.png',
                      'video': 'http://203.162.235.41:16910',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK BS1 (BS101)',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/6/6d/NHKBS1%E3%83%AD%E3%82%B42020-.png',
                      'video': 'http://203.162.235.41:16909',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK General (JOAK-DTV)',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/6/6f/NHK%E7%B7%8F%E5%90%88%E3%83%AD%E3%82%B42020-.png',
                      'video': 'http://203.162.235.41:16903',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK General TV',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/6/6f/NHK%E7%B7%8F%E5%90%88%E3%83%AD%E3%82%B42020-.png',
                      'video': 'https://nhk.mov3.co/hls/nhk.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK World',
                      'thumb': 'https://www3.nhk.or.jp/nhkworld/common/site_images/nw_webapp_1500x1500.png',
                      'video': 'https://nhkworld.webcdn.stream.ne.jp/www11/nhkworld-tv/sycc-live/zh/playlist.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK World Japan (1080p)',
                      'thumb': 'https://i.imgur.com/SQISXoD.jpg',
                      'video': 'https://nhkwlive-ojp.akamaized.net/hls/live/2003459/nhkwlive-ojp-en/index.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK World Japan',
                      'thumb': 'https://i.imgur.com/SQISXoD.jpg',
                      'video': 'https://nhkwlive-xjp.akamaized.net/hls/live/2003458/nhkwlive-xjp-en/index_600k.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'NHK华语视界 (720p)',
                      'thumb': 'http://www.tvyan.com/uploads/dianshi/nhkhuayu.jpg',
                      'video': 'https://nhkworld.webcdn.stream.ne.jp/www11/nhkworld-tv/zh/725580/livecom_zh.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'Nippon TV News 24',
                      'thumb': 'https://www.ntv.co.jp/englishnews/images/ogp.png',
                      'video': 'https://n24-cdn-live-b.ntv.co.jp/ch01/High.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'TBS',
                      'thumb': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Tokyo_Broadcasting_System_logo_2020.svg/1280px-Tokyo_Broadcasting_System_logo_2020.svg.png',
                      'video': 'https://tbs.mov3.co/hls/tbs.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': 'WOWOWシネマ (Wowow Cinema)',
                      'thumb': 'https://static.wikia.nocookie.net/logopedia/images/c/c1/Wowow_cinema.jpg',
                      'video': 'http://203.162.235.41:16916',
                      'genre': 'TV JAPAN'},
                      {'name': 'ジャパネットチャンネルDX',
                      'thumb': 'http://cc-tvguide.myjcom.jp/monomedia/ch_logo/jcom/logo-65406-548-400x400.png',
                      'video': 'http://bcsecurelivehls-i.akamaihd.net/hls/live/265320/5043843989001/140130JTDX/index_1200.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': '日本购物1',
                      'thumb': 'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
                      'video': 'http://stream1.shopch.jp/HLS/out1/prog_index.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': '日本购物2',
                      'thumb': 'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
                      'video': 'http://stream1.shopch.jp/HLS/out2/prog_index.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': '日本购物3',
                      'thumb': 'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
                      'video': 'http://stream1.shopch.jp/HLS/out3/prog_index.m3u8',
                      'genre': 'TV JAPAN'},
                      {'name': '日本购物4',
                      'thumb': 'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
                      'video': 'http://stream1.shopch.jp/HLS/out4/prog_index.m3u8',
                      'genre': 'TV JAPAN'}
                      ]}

def get_url(**kwargs):

    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_categories():

    return VIDEOS.keys()


def get_videos(category):

    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, 'LIVE TV & VOD XXX')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': category,
                                    'genre': category,
                                    'mediatype': 'video'})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': video['name'],
                                    'genre': video['genre'],
                                    'mediatype': 'video'})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        url = get_url(action='play', video=video['video'])

        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
