import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin
from lib.resolveurl import ResolveUrl
from lib.resolveurl.plugins import doodstream

# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

#                      {'name': '',
#                      'thumb': '',
#                      'video': '',
#                      'genre': 'SPORTS'}
#

VIDEOS = {
    'SPORTS CHANNEL': [{
        'name':
        '<!--BEIN SPORTS 1,2,3 MAX MENGGUNAKAN CLOUDFARE 1.1.1.1 VPN-->',
        'thumb': '',
        'video': '#',
        'genre': ''
    }, {
        'name': 'BEIN SPORTS 4 MAX FRANCE',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/d/d0/Logo-bein-sports-max-4-hd_1ut2dcsfzw7zj1204z6hz3qkhp-1-.jpg',
        'video':
        'http://31.220.41.88:8081/live/fr-beinmax4.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 5 MAX FRANCE',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/d/d0/Bein-sports-max-5_uioihjesc6nw1p6ydjpmkhsr6-1-.jpg',
        'video':
        'http://31.220.41.88:8081/live/fr-beinmax5.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 6 MAX FRANCE',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/c/c7/BE_IN_SPORT_MAX_6_HD_2017.jpg',
        'video':
        'http://31.220.41.88:8081/live/fr-beinmax6.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'iTV Sports',
        'thumb': 'https://i.imgur.com/SsgOgRF.png',
        'video':
        'https://sportportal1.akamaized.net/hls/live/702646/itvlive/ITV1PORTAL2/master.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'iTV (720)',
        'thumb': 'https://i.imgur.com/SsgOgRF.png',
        'video':
        'http://sportportal1.akamaized.net/hls/live/702646/itvlive/ITV1PORTAL2/master_Main600.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'iTV (1080)',
        'thumb': 'https://i.imgur.com/SsgOgRF.png',
        'video':
        'http://sportportal1.akamaized.net/hls/live/702646/itvlive/ITV1PORTAL2/master_Main1800.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'TNT 2 (Brasil)',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/TNT_%28TV_Channel%29.svg/600px-TNT_%28TV_Channel%29.svg.png',
        'video':
        'https://glxlmn026c.singularcdn.net.br/playout_02/playlist-720p.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'TRUE SPORTS HD 3',
        'thumb': 'http://www.srivichaistudio.com/tv2018/2sporthd3.png',
        'video': 'http://77.83.117.60:8888/02_2sporthd3_720p/chunklist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'TRUE SPORTS HD 2 (720)',
        'thumb': 'http://www.srivichaistudio.com/tv2018/2sporthd2.png',
        'video': 'http://77.83.117.60:8888/02_2sporthd2_720p/chunklist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 1 MAX',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/8/84/BEMAX1.png',
        'video': 'http://x7hd.com:8888/najwan/najwan1234/3607',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 2 MAX',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/8/82/Logo-beinsports-max-2.png',
        'video': 'http://x7hd.com:8888/najwan/najwan1234/3608',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 3 MAX',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/a/ad/Bein-sports-max-3_1v5w0eus6ylho1rv2zxzeozee9-1-.jpg/revision/latest/scale-to-width-down/250?cb=20140414165136',
        'video': 'http://x7hd.com:8888/najwan/najwan1234/11213',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS MAX 2 ALTERNATIVE',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/8/82/Logo-beinsports-max-2.png',
        'video': 'http://3.0.20.58:8000/play/BeinMax2/index.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS MAX 3 ALTERNATIVE',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/a/ad/Bein-sports-max-3_1v5w0eus6ylho1rv2zxzeozee9-1-.jpg/revision/latest/scale-to-width-down/250?cb=20140414165136',
        'video': 'http://3.0.20.58:8000/play/BeinMax3/index.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS MAX 4 ALTERNATIVE',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/d/d0/Logo-bein-sports-max-4-hd_1ut2dcsfzw7zj1204z6hz3qkhp-1-.jpg',
        'video': 'http://3.0.20.58:8000/play/BeinMax4/index.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS ENGLISH 1 HD',
        'thumb': 'https://i.imgur.com/O0JJEna.png',
        'video': 'http://77.83.117.60:8888/02_epl1_720p_UK/chunklist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS ENGLISH 2 HD',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/c/c9/Logo_bein_sports_2.png',
        'video': 'http://77.83.117.60:8888/02_epl2_720p_UK/chunklist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'ESPN 2',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Espn2.svg/1280px-Espn2.svg.png',
        'video': 'https://gma2.blab.email/espn2.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 1 ARABIC',
        'thumb':
        'https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS1_DIGITAL_Mono.png',
        'video': 'http://31.220.41.88:8081/live/bein1.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 2 ARABIC',
        'thumb':
        'https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS2_DIGITAL_Mono.png',
        'video': 'http://31.220.41.88:8081/live/bein2.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BEIN SPORTS 3 ARABIC',
        'thumb':
        'https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS3_DIGITAL_Mono.png',
        'video': 'http://31.220.41.88:8081/live/bein3.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'NBCSN HD',
        'thumb':
        'https://www.pngfind.com/pngs/m/219-2193037_nbc-sports-nbcsn-boston-hd-png-download.png',
        'video':
        'http://stream.tvtap.live:8081/live/nbcsn.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'SKYNET SPORT HD',
        'thumb':
        'https://2.bp.blogspot.com/-M-nmvvoZ4BQ/W-ovqYaU13I/AAAAAAAAAxM/lYY2Ci2kYuMng3C2lz7SMWDkRn-GmzA5wCK4BGAYYCw/s1600/sky_net_sports_mm_hd.png',
        'video':
        'http://77.83.117.60:8888/03_skynetsporthd_720p/chunklist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'FOX SPORTS 1 HD',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Fox_Sports_1_logo.svg/1280px-Fox_Sports_1_logo.svg.png',
        'video':
        'https://austchannel-live.akamaized.net/hls/live/2002736/austchannel-sport/master.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BT SPORTS 1 HD',
        'thumb':
        'https://www.thesportsdb.com/images/media/logo/4osx7y1579351981.png',
        'video': 'http://stream.tvtap.live:8081/live/bt1.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BT SPORTS 2 HD',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/1/17/BTSPORT_2_BLACK_RGB.png',
        'video':
        'http://stream.tvtap.live:8081/live/bt220.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'BT SPORTS 3 HD',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/4/42/BTSPORT_3_BLACK_RGB.png',
        'video':
        'http://stream.tvtap.live:8081/live/bt33.stream/playlist.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'ASTRO ARENA',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/8/82/EUROARENALOGO.png',
        'video': 'http://3.0.20.58:8000/play/Arena/index.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'ASTRO SUPER SPORT 1',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/7/7d/Astro_SuperSport_1.png',
        'video': 'http://3.0.20.58:8000/play/ASSP1/index.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'ASTRO SUPER SPORT 2',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/6/6b/Astro_SuperSport_2.png',
        'video': 'http://3.0.20.58:8000/play/ASSP2/index.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'ASTRO SUPER SPORT 3',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/e/e7/Astro_SuperSport_3.png',
        'video': 'http://3.0.20.58:8000/play/ASSP3/index.m3u8',
        'genre': 'SPORTS'
    }, {
        'name': 'ASTRO SUPER SPORT 4',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/d/d4/Astro_SuperSport_4.png',
        'video': 'http://3.0.20.58:8000/play/ASSP4/index.m3u8',
        'genre': 'SPORTS'
    }],
    'SPORTTV HD': [{
        'name': 'SPORTTV 1 HD',
        'thumb':
        'https://www.thesportsdb.com/images/media/logo/qpyqws1470407526.png',
        'video': 'http://77.83.117.60:8888/02_SPORTTV_1_720p/chunklist.m3u8',
        'genre': 'SPORTTV HD'
    }, {
        'name': 'SPORTTV 2 HD',
        'thumb':
        'https://www.thesportsdb.com/images/media/logo/qpyrpq1470407606.png',
        'video': 'http://77.83.117.60:8888/02_SPORTTV_2_720p/chunklist.m3u8',
        'genre': 'SPORTTV HD'
    }, {
        'name': 'SPORTTV 3 HD',
        'thumb':
        'https://www.thesportsdb.com/images/media/logo/xysrvw1470407766.png',
        'video': 'http://77.83.117.60:8888/02_SPORTTV_3_720p/chunklist.m3u8',
        'genre': 'SPORTTV HD'
    }, {
        'name': 'SPORTTV 1 HD ALTERNATIVE',
        'thumb':
        'https://www.thesportsdb.com/images/media/logo/qpyqws1470407526.png',
        'video':
        'http://31.220.41.88:8081/live/pt-sporttv1.stream/playlist.m3u8',
        'genre': 'SPORTTV HD'
    }, {
        'name': 'SPORTTV 2 HD ALTERNATIVE',
        'thumb':
        'https://www.thesportsdb.com/images/media/logo/qpyrpq1470407606.png',
        'video':
        'http://31.220.41.88:8081/live/pt-sporttv2.stream/playlist.m3u8',
        'genre': 'SPORTTV HD'
    }, {
        'name': 'SPORTTV 3 HD ALTERNATIVE',
        'thumb':
        'https://www.thesportsdb.com/images/media/logo/xysrvw1470407766.png',
        'video':
        'http://31.220.41.88:8081/live/pt-sporttv3.stream/playlist.m3u8',
        'genre': 'SPORTTV HD'
    }],
    'TV JAPAN': [{
        'name': 'Animax',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Animax.svg/1200px-Animax.svg.png',
        'video':
        'http://210.210.155.35:80/session/0a7f45f8-2efe-11eb-a328-c81f66f89318/dr9445/h/h144/01.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'Aniplus',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/b/b8/Aniplus_Asia_Logo.png',
        'video': 'http://210.210.155.35/dr9445/h/h02/01.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'AT-X',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/AT-X_logo.svg/1200px-AT-X_logo.svg.png',
        'video': 'https://sub2.neetball.net/live/neet.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'Bloomberg TV Asia',
        'thumb':
        'https://www.logolynx.com/images/logolynx/97/97553a1190d11e7536d169f9c2729457.png',
        'video':
        'https://liveprodapnortheast.global.ssl.fastly.net/btv/desktop/ap_live.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'BS Asahi',
        'thumb':
        'https://company.tv-asahi.co.jp/saiyo/group/img/company/logo-bsasahi.png',
        'video': 'http://203.162.235.41:16914',
        'genre': 'TV JAPAN'
    }, {
        'name': 'BS Fuji',
        'thumb':
        'https://www.zne-iptv.com/wp-content/uploads/2017/10/22-BS-FUJI-770x480.jpg',
        'video': 'http://203.162.235.41:16911',
        'genre': 'TV JAPAN'
    }, {
        'name': 'BS TV Tokyo',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TV_Tokyo_logo_20110629.svg/1280px-TV_Tokyo_logo_20110629.svg.png',
        'video': 'http://203.162.235.41:16915',
        'genre': 'TV JAPAN'
    }, {
        'name': 'BS 日テレ',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/BS4_logo.svg/400px-BS4_logo.svg.png',
        'video': 'http://203.162.235.41:16912',
        'genre': 'TV JAPAN'
    }, {
        'name': 'BS-TBS',
        'thumb':
        'https://pbs.twimg.com/profile_images/1260862250295812096/a6-UyLc__400x400.jpg',
        'video': 'http://203.162.235.41:16913',
        'genre': 'TV JAPAN'
    }, {
        'name': 'CGNTV Japan',
        'thumb': 'https://i.imgur.com/rXrSsiI.jpg',
        'video':
        'http://cgntv-glive.ofsdelivery.net/live/_definst_/cgntv_jp/playlist.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'Disney Channel Japan',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Disney_channel_2019.png/200px-Disney_channel_2019.png',
        'video': 'http://redlabmcdn.s.llnwi.net/jp01/bs13/index.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'Fuji TV',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/fr/thumb/6/65/Fuji_TV_Logo.svg/1049px-Fuji_TV_Logo.svg.png',
        'video': 'http://203.162.235.41:16904',
        'genre': 'TV JAPAN'
    }, {
        'name': 'GSTV',
        'thumb': 'https://i.imgur.com/8AM9fC8.jpg',
        'video':
        'https://gemstv.wide-stream.net/gemstv01/smil:gemstv01.smil/chunklist.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'GTN Typhome (English)',
        'thumb': 'https://i.imgur.com/gFKvgAd.jpg',
        'video': 'https://gorilla.gaki-no-tsukai.eu/hls/test.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'GUNMA TV',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Gtv_logo_ja_01.svg/800px-Gtv_logo_ja_01.svg.png',
        'video': 'https://movie.mcas.jp/switcher/smil:mcas8.smil/master.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'Hiroshima Weather Information',
        'thumb': 'https://i.imgur.com/ZoYNgdd.png',
        'video':
        'https://hiroshima-tv-live.hls.wselive.stream.ne.jp/hiroshima-tv-live/live/playlist.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'Japan Channel DX',
        'thumb':
        'https://img.japanet.co.jp/shopping/img/senqua/header/logo.gif',
        'video':
        'https://bcsecurelivehls-i.akamaihd.net/hls/live/265320/5043843989001/140130JTDX/index.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'JSTV 2',
        'thumb':
        'https://www.monpetitforfait.com/comparateur-box-internet/wp-content/uploads/2020/05/jstv2-regarder.png',
        'video': 'http://203.162.235.41:16901',
        'genre': 'TV JAPAN'
    }, {
        'name': 'MX Live (Webcam)',
        'thumb': 'https://i.imgur.com/WLgD1v7.png',
        'video': 'https://movie.mcas.jp/mcas/mx_live_2/master.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'MX 1 JAPAN',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/5/5f/566456.jpg',
        'video': 'https://movie.mcas.jp/mcas/mx1_2/chunklist.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'MX 2 JAPAN',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/9/93/52323.jpg',
        'video': 'https://movie.mcas.jp/mcas/mx2_2/chunklist.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK BS Premium (BS103)',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/2/21/NHK_BS%E3%83%97%E3%83%AC%E3%83%9F%E3%82%A2%E3%83%A0_%E6%96%B0%E3%83%AD%E3%82%B4.png',
        'video': 'http://203.162.235.41:16910',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK BS1 (BS101)',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/6/6d/NHKBS1%E3%83%AD%E3%82%B42020-.png',
        'video': 'http://203.162.235.41:16909',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK General (JOAK-DTV)',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/6/6f/NHK%E7%B7%8F%E5%90%88%E3%83%AD%E3%82%B42020-.png',
        'video': 'http://203.162.235.41:16903',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK General TV',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/6/6f/NHK%E7%B7%8F%E5%90%88%E3%83%AD%E3%82%B42020-.png',
        'video': 'https://nhk.mov3.co/hls/nhk.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK World',
        'thumb':
        'https://www3.nhk.or.jp/nhkworld/common/site_images/nw_webapp_1500x1500.png',
        'video':
        'https://nhkworld.webcdn.stream.ne.jp/www11/nhkworld-tv/sycc-live/zh/playlist.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK World Japan (1080p)',
        'thumb': 'https://i.imgur.com/SQISXoD.jpg',
        'video':
        'https://nhkwlive-ojp.akamaized.net/hls/live/2003459/nhkwlive-ojp-en/index.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK World Japan',
        'thumb': 'https://i.imgur.com/SQISXoD.jpg',
        'video':
        'https://nhkwlive-xjp.akamaized.net/hls/live/2003458/nhkwlive-xjp-en/index_600k.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'NHK华语视界 (720p)',
        'thumb': 'http://www.tvyan.com/uploads/dianshi/nhkhuayu.jpg',
        'video':
        'https://nhkworld.webcdn.stream.ne.jp/www11/nhkworld-tv/zh/725580/livecom_zh.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'Nippon TV News 24',
        'thumb': 'https://www.ntv.co.jp/englishnews/images/ogp.png',
        'video': 'https://n24-cdn-live-b.ntv.co.jp/ch01/High.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'TBS',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Tokyo_Broadcasting_System_logo_2020.svg/1280px-Tokyo_Broadcasting_System_logo_2020.svg.png',
        'video': 'https://tbs.mov3.co/hls/tbs.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': 'WOWOWシネマ (Wowow Cinema)',
        'thumb':
        'https://static.wikia.nocookie.net/logopedia/images/c/c1/Wowow_cinema.jpg',
        'video': 'http://203.162.235.41:16916',
        'genre': 'TV JAPAN'
    }, {
        'name': 'ジャパネットチャンネルDX',
        'thumb':
        'http://cc-tvguide.myjcom.jp/monomedia/ch_logo/jcom/logo-65406-548-400x400.png',
        'video':
        'http://bcsecurelivehls-i.akamaihd.net/hls/live/265320/5043843989001/140130JTDX/index_1200.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': '日本购物1',
        'thumb':
        'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
        'video': 'http://stream1.shopch.jp/HLS/out1/prog_index.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': '日本购物2',
        'thumb':
        'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
        'video': 'http://stream1.shopch.jp/HLS/out2/prog_index.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': '日本购物3',
        'thumb':
        'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
        'video': 'http://stream1.shopch.jp/HLS/out3/prog_index.m3u8',
        'genre': 'TV JAPAN'
    }, {
        'name': '日本购物4',
        'thumb':
        'https://3.bp.blogspot.com/-7ImOsWi31RQ/XudULypi_dI/AAAAAAAAeNU/n0fGEDPMegkBNJ8LLjbap-rGczuJhfYpgCPcBGAYYCw/s1600/Japan-tax-free-tax-exempt-refund-return-logo-%25E5%2585%258D%25E7%25A8%258E%25E3%2581%25AE%25E3%2583%25AD%25E3%2582%25B3%25E3%2582%2599.jpg',
        'video': 'http://stream1.shopch.jp/HLS/out4/prog_index.m3u8',
        'genre': 'TV JAPAN'
    }],
    'TV INDONESIAN': [{
        'name': 'ARIRANG',
        'thumb': 'http://kamiselaluada.com/img/arirang.png',
        'video':
        'https://amdlive-ch01-ctnd-com.akamaized.net/arirang_1ch/smil:arirang_1ch.smil/chunklist_b3256000_sleng.m3u8',
        'genre': 'TV INDONESIAN'
    }, {
        'name': 'ELSHINTA TV',
        'thumb': 'https://i.postimg.cc/hGcg87rw/elshintatv.png',
        'video': 'http://45.126.83.51/qwr9ew/s/s10/01.m3u8',
        'genre': 'TV INDONESIAN'
    }, {
        'name': 'ANTV',
        'thumb': 'https://i.postimg.cc/DyWXD5DD/antv.png',
        'video': 'http://210.210.155.35/qwr9ew/s/s07/02.m3u8',
        'genre': 'TV INDONESIAN'
    }, {
        'name': 'JOGJA TV',
        'thumb':
        'https://i.postimg.cc/DznwDyMD/LOGO-JOGJA-TV-NEW-pii-new1.png',
        'video': 'https://stream.jogjatv.co.id/jtvlive/stream/index.m3u8',
        'genre': 'TV INDONESIAN'
    }, {
        'name': 'CNBC INDONESIA',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/id/3/35/CNBC_Indonesia.png',
        'video':
        'https://live.cnbcindonesia.com/livecnbc/smil:cnbctv.smil/master.m3u8',
        'genre': 'TV INDONESIAN'
    }, {
        'name': 'CNN INDONESIA',
        'thumb': 'https://i.postimg.cc/NG7pqNFz/1200px-CNN-Indonesia-svg.png',
        'video':
        'https://live.cnnindonesia.com/livecnn/smil:cnntv.smil/playlist.m3u8',
        'genre': 'TV INDONESIAN'
    }, {
        'name': 'BERITASATU',
        'thumb': 'https://i.postimg.cc/W1f5Yhzp/14040323.png',
        'video':
        'https://b1news.beritasatumedia.com/Beritasatu/B1News_960x540.m3u8',
        'genre': 'TV INDONESIAN'
    }],
    'MOVIES CHANNELS FULL HD': [{
        'name': '&Flix HD',
        'thumb': 'https://static.epg.best/in/AndFlix.in.png',
        'video':
        'https://y5w8j4a9.ssl.hwcdn.net/andflixhd/tracks-v1a1/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': '&Prive HD',
        'thumb':
        'https://upload.wikimedia.org/wikipedia/en/4/4f/Logo_of_%26_Priv%C3%A9_HD.jpg',
        'video':
        'https://y5w8j4a9.ssl.hwcdn.net/andprivehd/tracks-v1a1/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Maverick Movies',
        'thumb': 'https://i.imgur.com/Zk5wP5K.png',
        'video':
        'https://dai2.xumo.com/amagi_hls_data_xumo1212A-redbox-maverickmovies/CDN/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'MBC 2 (1080P)',
        'thumb': 'https://i.imgur.com/KXuzL1u.png',
        'video':
        'https://shls-mbc2-prod-dub.shahid.net/out/v1/b4befe19798745fe986f5a9bfba62126/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'MBC Action (1080P)',
        'thumb': 'https://i.imgur.com/n3TgfP0.png',
        'video':
        'https://shls-mbcaction-prod-dub.shahid.net/out/v1/68dd761538e5460096c42422199d050b/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'MBC Max (1080P)',
        'thumb': 'https://i.imgur.com/X6EliFm.png',
        'video':
        'https://shls-mbcmax-prod-dub.shahid.net/out/v1/13815a7cda864c249a88c38e66a2e653/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'MBCPlus Drama (1080P)',
        'thumb': 'https://i.imgur.com/F5ER0we.png',
        'video':
        'https://shls-mbcplusdrama-prod-dub.shahid.net/out/v1/97ca0ce6fc6142f4b14c0a694af59eab/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'AXN HD (BRASIL)',
        'thumb': 'http://epg.it999.ru/img/3040.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6162/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Bein Movies HD 2 (Action)',
        'thumb': 'http://epg.it999.ru/img/3081.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6134/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Bein Movies HD 3 (Drama)',
        'thumb': 'http://epg.it999.ru/img/3082.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6135/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Bein Movies HD 4 (Familly)',
        'thumb': 'http://epg.it999.ru/img/3083.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6136/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Bein Series HD 1',
        'thumb': 'http://epg.it999.ru/img/3084.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6138/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Bein FX Movies HD',
        'thumb': 'http://epg.it999.ru/img/3086.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6144/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Bein Fox Movies HD',
        'thumb': 'http://epg.it999.ru/img/3086.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6145/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Fox HD',
        'thumb': 'http://epg.it999.ru/img/1031.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/9018/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Fox Crime',
        'thumb': 'http://epg.it999.ru/img/3861.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6803/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Fox Life',
        'thumb': 'http://epg.it999.ru/img/3859.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6800/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Movie Smart Gold',
        'thumb': 'http://epg.it999.ru/img/3866.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6810/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Disney Turkey',
        'thumb': 'http://epg.it999.ru/img/150.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/9183/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Discovery Ultra 4K',
        'thumb': 'http://epg.it999.ru/img/4620.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/10048/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'HBO HD',
        'thumb': 'http://epg.it999.ru/img/3728.png',
        'video': 'http://185.183.34.118/iptv/LZKA5RU8PUWYR3/6986/index.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Disney XD',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/disneyxd.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Cartoon Network',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-cartoon.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'CBS',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/us-cbs.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Cinemax',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-cinemax.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Cinemax Action',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-cinemaxaction.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Comedy Central',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-comedy.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Dave',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/dave.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Discovery Channel',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-discovery.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Disney USA',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-disney.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'ES Movistar Deportes',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/es-movistar-deportes.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'ES Movistar Deportes 2',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/es-movistar-deportes2.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'ES Movistar Laliga',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/bein-laliga.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Fox',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/us-fox.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'FreeFrom',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-freeform.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'FX Channel',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/us-fx.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'FXX Channel',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/us-fxx.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Hallmark',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-hallmark.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'HBO USA',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/us-hbo.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'HBO Familly',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-hbofamily.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'HBO Zone',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/us-hbozone.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Sky Cinema Drama',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/mdrama.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Nickelodeon',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/us-nick.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Nick JR',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/uk-nickjr.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Sky Movies Action & Adventure',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/maction.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Sky Movies Familly',
        'thumb': '',
        'video': 'http://31.220.41.88:8081/live/mfamily.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }, {
        'name': 'Sky Mix',
        'thumb': '',
        'video':
        'http://31.220.41.88:8081/live/skysportsmix.stream/playlist.m3u8',
        'genre': 'MOVIES CHANNELS'
    }],
    'MOVIES FUNNY': [{
        'name': 'TVMatic Comedy',
        'thumb': '',
        'video': 'http://cdn.tvmatic.net/comedy.m3u8',
        'genre': 'MOVIES FUNNY'
    }, {
        'name': 'TVMatic Sport',
        'thumb': '',
        'video': 'http://cdn.tvmatic.net/sport.m3u8',
        'genre': 'MOVIES FUNNY'
    }, {
        'name': 'TVMatic Funny',
        'thumb': '',
        'video': 'http://cdn.tvmatic.net/funny.m3u8',
        'genre': 'MOVIES FUNNY'
    }, {
        'name': 'TVMatic Tiktok',
        'thumb': '',
        'video': 'http://cdn.tvmatic.net/tiktok.m3u8',
        'genre': 'MOVIES FUNNY'
    }, {
        'name': 'TVMatic Fight',
        'thumb': '',
        'video': 'http://cdn.tvmatic.net/fight.m3u8',
        'genre': 'MOVIES FUNNY'
    }, {
        'name': 'TVMatic Crafts',
        'thumb': '',
        'video': 'http://cdn.tvmatic.net/crafts.m3u8',
        'genre': 'MOVIES FUNNY'
    }, {
        'name': 'TVMatic Facebook',
        'thumb': '',
        'video': 'http://cdn.tvmatic.net/facebook.m3u8',
        'genre': 'MOVIES FUNNY'
    }],
    'MOVIES & SPORTS CHANNEL HD': [{
        'name': 'SuperSport PSL',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28894',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport LaLiga',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28895',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Premier League ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28896',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Grandstand ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28897',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Variety 2 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28898',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Variety 1 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28899',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Action ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28900',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Football ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28901',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Variety 4 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28902',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Variety 3 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28903',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Rugby ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28904',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Cricket ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28905',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Blitz ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28906',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Maximo 1 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28907',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'Soweto TV ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28908',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'M-Net Movies 2 ZA',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28909',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'Cape Town TV ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28910',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'Ginx eSports Africa ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28911',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'HGTV ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28912',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SABC News ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28913',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SABC 1 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28914',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SABC 2 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28915',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SABC 3 ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28916',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'TV5 Monde Afrique ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28917',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'Newzroom Afrika ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28918',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'M-Net Movies 1 ZA',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28920',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'M-Net Movies 4 ZA',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28921',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'M-Net Movies 3  ZA',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28922',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'M-Net ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28923',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'Africa Magic Epic ZA',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28924',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'Africa Magic Family ZA',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28925',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'E TV ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28927',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'E Toonz ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28928',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'E Extra ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28929',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': '1KZN TV ZA',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28930',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'Bay TV ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28931',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'TCV Internacional CV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/29472',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'KykNet ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/29857',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Golf ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/54965',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Tennis ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/54966',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }, {
        'name': 'SuperSport Motorsport ',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/54967',
        'genre': 'MOVIES & SPORTS CHANNEL HD'
    }],
    'UNITED KINGDOM MOVIES & SPORTS': [{
        'name': '5Star +1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14732',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': '5USA +1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14731',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Racing UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1997',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ARY Digital UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/21538',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'B4U Plus UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/25585',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Virgin Media Two HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/20027',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': '4Music UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1951',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': '4Seven UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3961',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Alibi HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16729',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Animal Planet HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/8010',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ARY Family UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/28174',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ARY World UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/21539',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BBC Alba UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14703',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BBC News UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/4020',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BBC World News UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/18385',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BBC One CI UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14700',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BBC One E Mid UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14699',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BBC One East E UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14698',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BBC Scotland UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14679',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BEN UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14972',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BET UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14848',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Betfred TV1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27030',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Betfred TV2 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27031',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Betfred TV3 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27032',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Blaze UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/19675',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport 1 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1991',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport 2 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1992',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport 3 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14903',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport Box Office HD',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/23755',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport ESPN UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/2673',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport Extra 1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14778',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport Extra 2 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14809',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport Extra 3 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14808',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BT Sport Extra 4 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14807',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Baby TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/11425',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Fuel TV Europe UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14811',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Bloomberg TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/8298',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Boomerang UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1962',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'BoxNation UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/4010',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Box Hits UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/20254',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'British Muslim TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14971',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CBBC HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/12348',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CBS Drama UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3945',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CBS Reality +1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14776',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CBS Reality UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3946',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CBeebies UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3582',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CGTN HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14970',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Celtic TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16800',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CITV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/9588',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CNBC UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14968',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'CNN UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3995',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Cartoon Network HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3967',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Challenge UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14945',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Channel 4 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14890',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Channel 4 London UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/2681',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Channel 4 Midlands UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14889',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Comedy Central UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3948',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Crime + Investigation UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14943',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'DMAX UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1983',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Dave HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/8012',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Discovery Channel HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14863',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Discovery Science UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/2679',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Discovery Turbo UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3978',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Disney Junior HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3969',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Drama UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3957',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Dunya News UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14881',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Eden HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/20028',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Eurosport 1 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/13091',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Eurosport 2 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/13092',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'FOX HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/2656',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Film 4 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/19136',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Fashion TV HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/21120',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Food Network UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3991',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Forces TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/12354',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'FreeSports UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/19642',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Geo Tez UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15041',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Geo TV Network UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14838',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'God Channel UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15040',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'GOLD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14963',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky History 2 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3569',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky History HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3976',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'HGTV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14961',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Horror Channel UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3941',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV Westcountry South West UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14725',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV Be HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16723',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV Box Office TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16914',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV Meridian South UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14719',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV 1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3576',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV 2 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/18899',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV 3 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14738',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'ITV 4 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3583',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Iqra TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/25584',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Pop Max +1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14875',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Ladbrokes 1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27029',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Ladbrokes 2 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27026',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Lifetime HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14938',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Liverpool FC TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3568',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'London Live UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14958',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'MTV HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/20031',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'MTV Base UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/7319',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'MTV Classic UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/7320',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Club MTV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/7318',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'MTV Hits UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/7317',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'MTV Music UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/7316',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'MTV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/2670',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Manchester United TV',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/2655',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Madani Channel UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14957',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'More 4 HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16724',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sony Movies Action UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1971',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'My Channel UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15027',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': '5Select UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14709',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'National Geographic HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3561',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'National Geographic Wild HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1968',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Nick HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16719',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Nick Jr. +1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14829',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Nick Jr. UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/2669',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Nickelodeon UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14825',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'NickToons UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14824',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Noor TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15025',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'PBS America UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14870',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Pop +1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14868',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Racing HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15019',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sony SAB UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14820',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'STV East UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14708',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Showcase UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15014',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky One HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/8011',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Two UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3573',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Action & Adventure UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3559',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Comedy UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3563',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Crime & Thriller UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1955',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Drama & Romance UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1960',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Family HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3926',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Greats UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1959',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Hits UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16503',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Premiere HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1958',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Sci-Fi & Horror UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/1957',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Cinema Select HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14765',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Witness HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16720',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky News UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3570',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Action HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3598',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Arena HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16968',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Main Event HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/5600',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Cricket HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/5601',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Football HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/20024',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Golf HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3600',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Premier League HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/4458',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Box Office UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14756',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports F1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14739',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sky Sports Mix HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14902',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'SIS1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27023',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'SIS2 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27028',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sonlife TV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15013',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Sony UNITED KINGDOM',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14790',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Star Gold UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/12351',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Star Jalsha UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/12352',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Star Plus UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14788',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Syfy HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16727',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'TBN UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/15008',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'TG4 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/4005',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Tiny Pop UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/9898',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'UTV UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/14704',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'VH1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3943',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'WH1 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27033',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'WH2 UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/27034',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'W HD UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/16726',
        'genre': 'UNITED KINGDOM'
    }, {
        'name': 'Yesterday UK',
        'thumb': '',
        'video': 'http://85.217.223.138:80/fn3huGQ/1AsGbU/3962',
        'genre': 'UNITED KINGDOM'
    }]
}


def get_url(**kwargs):

    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_categories():

    return VIDEOS.keys()


def get_videos(category):

    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, 'LIVE TV & VOD')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({
            'thumb': VIDEOS[category][0]['thumb'],
            'icon': VIDEOS[category][0]['thumb'],
            'fanart': VIDEOS[category][0]['thumb']
        })
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': category,
            'genre': category,
            'mediatype': 'video'
        })
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        #url = get_url(action='listing', category=category)
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {
            'title': video['name'],
            'genre': video['genre'],
            'mediatype': 'video'
        })
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({
            'thumb': video['thumb'],
            'icon': video['thumb'],
            'fanart': video['thumb']
        })
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        #url = get_url(action='play', video=video['video'])
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
