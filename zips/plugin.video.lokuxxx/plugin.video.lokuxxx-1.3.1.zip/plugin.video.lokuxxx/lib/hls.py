import xbmc
from lib.resolveurl import ResolveUrl

from lib.resolveurl import ResolveUrl as urlresolver

url = 'https://doodstream.com/d/8372q44p96ht'
resolved = urlresolver.resolve(url)

xbmc.Player().play(resolved)