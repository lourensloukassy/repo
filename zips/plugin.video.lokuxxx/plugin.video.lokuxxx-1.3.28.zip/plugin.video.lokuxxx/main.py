import sys
from urllib.parse import urlencode, parse_qsl
import xbmc
import xbmcgui
import xbmcplugin
from lib import channel

_URL = sys.argv[0]

_HANDLE = int(sys.argv[1])

VIDEOS = channel.lokurepo


def get_url(**kwargs):

    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_categories():

    return VIDEOS.keys()


def get_videos(category):

    return VIDEOS[category]


def list_categories():

    xbmcplugin.setPluginCategory(_HANDLE, 'LIVE TV & VOD')

    xbmcplugin.setContent(_HANDLE, 'videos')

    categories = get_categories()

    for category in categories:

        list_item = xbmcgui.ListItem(label=category)

        list_item.setArt({
            'thumb': VIDEOS[category][0]['thumb'],
            'icon': VIDEOS[category][0]['thumb'],
            'fanart': VIDEOS[category][0]['thumb']
        })

        list_item.setInfo('video', {
            'title': category,
            'genre': category,
            'mediatype': 'video'
        })

        url = get_url(action='listing', category=category)

        is_folder = True

        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)

    xbmcplugin.endOfDirectory(_HANDLE)


def list_videos(category):

    xbmcplugin.setPluginCategory(_HANDLE, category)

    xbmcplugin.setContent(_HANDLE, 'videos')

    videos = get_videos(category)

    for video in videos:

        list_item = xbmcgui.ListItem(label=video['name'])

        list_item.setInfo('video', {
            'title': video['name'],
            'genre': video['genre'],
            'mediatype': 'video'
        })

        list_item.setArt({
            'thumb': video['thumb'],
            'icon': video['thumb'],
            'fanart': video['thumb']
        })

        list_item.setProperty('IsPlayable', 'true')

        url = get_url(action='play', video=video['video'])

        is_folder = False

        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)

    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):

    play_item = xbmcgui.ListItem(path=path)

    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):

    params = dict(parse_qsl(paramstring))

    if params:
        if params['action'] == 'listing':

            list_videos(params['category'])
        elif params['action'] == 'play':

            play_video(params['video'])
        else:

            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:

        list_categories()


if __name__ == '__main__':

    router(sys.argv[2][1:])
