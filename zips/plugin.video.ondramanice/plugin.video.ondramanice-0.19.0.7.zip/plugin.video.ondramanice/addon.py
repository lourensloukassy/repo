# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.error, urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import resolveurl as urlresolver  #contribution Lourens.R.L

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__ = 'plugin.video.ondramanice'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.ondramanice')

#Деклариране на константи
md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
MUA = 'Mozilla/5.0 (Linux; Android 7.1.1; en-us; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19'  #За симулиране на заявка от мобилно устройство
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0'  #За симулиране на заявка от  компютърен браузър
bu = 'https://dramanice.cx'  #'https://ondramanice.tv'

#Хедъри за заявки услугата
dn_headers = {
    'User-Agent': UA,
    'authority': 'dramanice.cx',
    'accept': 'application/json, text/plain, */*',
    'dnt': '1',
    'origin': bu,
    'Connection': 'keep-alive',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': bu,
    'accept-language': 'bg-BG,bg;q=0.9,en;q=0.8',
    'Accept-Encoding': 'gzip'
}


#Меню с директории в приставката
def CATEGORIES():
    addDir('Search', bu + '/search.html?keyword=', '', 6,
           md + 'DefaultAddonsSearch.png')
    addDir('List All Drama', bu + '/list-all-drama', '', 1,
           md + 'DefaultFolder.png')
    addDir('Drama Movies', bu + '/drama-movies', '', 1,
           md + 'DefaultFolder.png')
    addDir('Drama Show', bu + '/drama-show', '', 1, md + 'DefaultFolder.png')
    addDir('Most Popular Drama', bu + '/most-popular-drama?page=1', '', 5,
           md + 'DefaultFolder.png')
    #addDir('Папка','http://www.example.com','',1,md+'DefaultFolder.png')


#Разлистване на всички заглавия в каталога
def LISTALL(url):
    response = requests.get(url, headers=dn_headers)
    match = re.compile(
        '<li class=\"country-all country-\d{1,3}\">\n +<a href=\"(.+?)\" title=\"(.+?)\">'
    ).findall(response.text)
    for link, title in match:
        addDir(title, link, '', 2, md + 'DefaultFolder.png')


#Разлистване епизодите
def LISTEPISODES(url):
    response = requests.get(bu + url + '#view-more-episodes',
                            headers=dn_headers)

    matcht = re.compile('<h1 class="label_coming">(.+?)</h1>').findall(
        response.text)
    for name in matcht:
        title = name
    matchp = re.compile('<div class=\"info_des\">(.+?)</div>').findall(
        response.text.replace("\n", ""))
    for description in matchp:
        plot = description
    matchc = re.compile(
        '<meta itemprop=\"image\" content=\"(.+?)\"/>').findall(response.text)
    for coverimage in matchc:
        cover = coverimage

    #xbmcgui.Dialog().ok('OnDramaNice',bu+url)
    #xbmcgui.Dialog().ok('OnDramaNice',data.replace("\n", "").replace(" ", ""))
    matche = re.compile(
        '<li><ahref=\"(.+?)\".+?<span>(.+?)</span>.+?</li>').findall(
            response.text.replace("\n", "").replace(" ", ""))
    for link, number in matche:
        #print link
        addDir(title + ' ' + number.replace('|SUB', ''), link, plot, 3, cover)

    #matchvme = re.compile('rel="(.+?)" str-alias="(.+?)"').findall(data)
    #for sid, alias in matchvme:
    #	req = urllib2.Request(bu+'//load-episode.html?id='+sid+'&str='+alias)
    #	req.add_header('User-Agent', UA)
    #	response = urllib2.urlopen(req)
    #	data2=response.read()
    #	response.close()

    #	matche = re.compile('<li class=.*>\n      <a href=\"(.+?)\" title=\"(.+?)\" class=\"SUB\">\n        <span class=\"icon-play SUB\"><\/span>\n        <span>(.+?\d+) ').findall(data2)
    #	for link, title, number in matche:
    #		addDir(title+' '+number,link,plot,3,cover)


#Извличане хостърите на епизодите
def HOSTS(url):
    response = requests.get(bu + url, headers=dn_headers)

    #Обложка
    matchc = re.compile(
        '<meta itemprop=\"image\" content=\"(.+?)\"/>').findall(response.text)
    for coverimage in matchc:
        thumbnail = coverimage

    #Заглавие
    matchht = re.compile('<title>(.+?)</title>').findall(response.text)
    for t in matchht:
        title = t.replace("Watch ", "").replace(" English subbed", "").replace(
            " - ", "").replace("Dramanice", "").replace(" online at ", "")

    #Добавяне на Youtube търсене
    ok = True
    utube = 'plugin://plugin.video.youtube/search/?q=' + urllib.parse.quote_plus(
        title)
    item = xbmcgui.ListItem(title + ' (Search in YouTube)')
    item.setArt({
        'thumb': thumbnail,
        'poster': thumbnail,
        'banner': thumbnail,
        'fanart': thumbnail,
        'icon': thumbnail
    })
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                     url=utube,
                                     listitem=item,
                                     isFolder=True)

    #Страница с видеа 1
    try:
        matchhl1 = re.compile(
            'data-video=\"(.+?)\"><i class=\"iconlayer-\D{1,20}\"></i>(.+?)<span>'
        ).findall(response.text)
        for link, hoster in matchhl1:

            #HOSTERS
            if "Mp4Upload".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Mp4Upload", link, '', 'True',
                        '', '', '', '', 4, thumbnail)
            elif "Server m1".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Server m1", link, '', 'True',
                        '', '', '', '', 4, thumbnail)
            elif "Asianload".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Asianload", link, '', 'True',
                        '', '', '', '', 4, thumbnail)
            elif "Streamsb".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Streamsb", link, '', 'True',
                        '', '', '', '', 4, thumbnail)
            elif "Cloud9".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Cloud9", link, '', 'True', '',
                        '', '', '', 4, thumbnail)
            elif "Xstreamcdn".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Xstreamcdn", link, '', 'True',
                        '', '', '', '', 4, thumbnail)
            elif "Hydrax".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Hydrax", link, '', 'True', '',
                        '', '', '', 4, thumbnail)
            elif "Streamtape".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Streamtape", link, '', 'True',
                        '', '', '', '', 4, thumbnail)
            elif "Mixdrop".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Mixdrop", link, '', 'True', '',
                        '', '', '', 4, thumbnail)
            elif "Doodstream".lower() in hoster.lower():
                addLink(title + ' ' + "Play via Doodstream", link, '', 'True',
                        '', '', '', '', 4, thumbnail)
    except:
        pass

    #Страница с видеа 2
    try:
        matchhl = re.compile(
            '<a class=\"download_link\" href=\"(.+?)\"').findall(response.text)
        for link in matchhl:
            response2 = requests.get(link.replace("https://k-vid.co",
                                                  "https://kshows.to"),
                                     headers=dn_headers)

            #Заглавие
            matchht = re.compile('<title>(.+?)</title>').findall(
                response2.text)
            for t in matchht:
                title = t

            #Google
            matchhg = re.compile('href=\"(.+?)\" download>(.+?)</a>').findall(
                response2.text.replace("\n", ""))
            for link, resolution in matchhg:
                matchhgid = re.compile('driveid=(.+?)&amp').findall(link)
                for gid in matchhgid:
                    finallink = 'https://drive.google.com/file/d/' + gid + '/edit'
                    addLink(
                        title + ' ' + resolution.replace(
                            "Download", "").replace(" ", "").replace(
                                "P", "p").replace("-mp4", " via GoogleVideo"),
                        finallink, '', 'True', '', '', '', '', 4, thumbnail)
            matchhg2 = re.compile('href=\"(.+?google.+?)\" download>').findall(
                response2.text)
            for link in matchhg2:
                addLink(title + ' ' + 'Play via GoogleVideo', link, '', 'True',
                        '', '', '', '', 4, thumbnail)

            #Direct media link
            matchd = re.compile(
                'href=\"(.+?)\" download>Download\n +\(autoP - mp4\)</a>'
            ).findall(response2.text)
            for link in matchd:
                addLink(title + " (Direct Play)", link, '', 'True', '', '', '',
                        '', 4, thumbnail)
            matchd2 = re.compile('href=\"(.+?cdnfile.+?)\" download').findall(
                response2.text)
            for link in matchd2:
                addLink(title + " (Play via CDNFile)", link, '', 'True', '',
                        '', '', '', 4, thumbnail)

            #Mirror hosters
            matchmh = re.compile(
                'href=\"(.+?)\" target=.+?>(.+?)</a>').findall(response2.text)
            for link, hoster in matchmh:
                if not "Ad" in hoster:
                    addLink(
                        title + ' ' +
                        hoster.replace("Download ", "(Play via ") + ')', link,
                        '', 'True', '', '', '', '', 4, thumbnail)
    except:
        pass


#Зареждане на видео
def PLAY(url):
    #xbmcgui.Dialog().ok('URL', url)
    if 'http' not in url:
        url = 'http:' + url
    if 'cdnfile.info' in url:
        stream = url.replace(' ', '%20').replace(
            'https:', 'http:'
        ) + '|User-Agent=' + UA + '&connection-timeout=930&verifypeer=false'
        #print stream
        #xbmcgui.Dialog().ok('OnDramaNice',stream)
        li = xbmcgui.ListItem(path=stream + '|User-Agent=stagefright')
        #li.setArt({ 'thumb': cover,'poster': cover, 'banner' : cover, 'fanart': cover, 'icon': cover })
        li.setInfo(type="Video", infoLabels={'Title': name, 'Plot': ''})
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        except:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)' %
                                ('OnDramanice', 'Video stream is not playable',
                                 4000, md + 'DefaultIconError.png'))
    else:
        hmf = urlresolver.HostedMediaFile(url)
        if hmf:
            stream = str(urlresolver.resolve(
                url)) + '&connection-timeout=930&verifypeer=false'
            li = xbmcgui.ListItem(path=stream)
            li.setInfo(type="Video", infoLabels={"Title": name, "Plot": ''})
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        else:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)' %
                                ('OnDramanice', 'Hoster Not Suported', 4000,
                                 md + 'DefaultIconError.png'))


#Разлистване на популярните заглавия
def POPULAR(url):
    response = requests.get(url, headers=dn_headers)

    #Зона
    matchz = re.compile('<a(.+?)</a>').findall(response.text.replace('\n', ''))
    for zone in matchz:
        #Заглавие и линк
        matchtl = re.compile('href=\"(.+?)\" title=\"(.+?)\"').findall(zone)
        for link, title in matchtl:
            #Обложка
            matchc = re.compile('img src=\"(.+?)\"').findall(zone)
            for cover in matchc:
                addDir(title, link, '', 2, cover)

    #Следваща страница...
    getpage = re.compile('(.+?)?page=(.+?)').findall(url.decode('utf-8'))
    for fronturl, page in getpage:
        newpage = int(page) + 1
        url = fronturl + '&page=' + str(newpage)
        addDir('Go to page ' + str(newpage) + ' >>', url, '', 5,
               md + 'DefaultFolder.png')


#Търсачка
def SEARCH(url):
    keyb = xbmc.Keyboard('', 'Search in Dramanice Database')
    keyb.doModal()
    searchText = ''
    if (keyb.isConfirmed()):
        searchText = urllib.parse.quote_plus(keyb.getText())
        searchText = searchText.replace(' ', '+')
        searchurl = url + searchText
        searchurl = searchurl.encode('utf-8')
        #print 'SEARCHING:' + searchurl
        POPULAR(searchurl)
    else:
        addDir('Go to main menu...', '', '', '', md + 'DefaultFolderBack.png')


#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name, url, vd, hd, plot, author, rating, ar, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(
        mode) + "&name=" + urllib.parse.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({
        'thumb': iconimage,
        'poster': iconimage,
        'banner': iconimage,
        'fanart': iconimage,
        'icon': iconimage
    })
    liz.setInfo(type="Video",
                infoLabels={
                    "title": name,
                    "duration": vd,
                    "plot": plot,
                    "rating": ar,
                    "studio": author,
                    "mpaa": rating
                })
    if hd == 'True':
        liz.addStreamInfo('video', {'width': 1280, 'height': 720})
        liz.addStreamInfo('video', {'aspect': 1.78, 'codec': 'h264'})
    else:
        liz.addStreamInfo('video', {'width': 720, 'height': 480})
        liz.addStreamInfo('video', {'aspect': 1.5, 'codec': 'h264'})
    liz.addStreamInfo('audio', {'codec': 'aac', 'channels': 2})
    liz.setProperty("IsPlayable", "true")
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                     url=u,
                                     listitem=liz,
                                     isFolder=False)
    return ok


#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name, url, plot, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(
        mode) + "&name=" + urllib.parse.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({
        'thumb': iconimage,
        'poster': iconimage,
        'banner': iconimage,
        'fanart': iconimage,
        'icon': 'DefaultFolder.png'
    })
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": plot})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                     url=u,
                                     listitem=liz,
                                     isFolder=True)
    return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()
url = None
name = None
iconimage = None
mode = None

try:
    url = urllib.parse.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.parse.unquote_plus(params["name"])
except:
    pass
try:
    name = urllib.parse.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode == None or url == None or len(url) < 1:
    CATEGORIES()

elif mode == 1:
    LISTALL(url)

elif mode == 2:
    LISTEPISODES(url)

elif mode == 3:
    HOSTS(url)

elif mode == 4:
    PLAY(url)

elif mode == 5:
    POPULAR(url)

elif mode == 6:
    SEARCH(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
